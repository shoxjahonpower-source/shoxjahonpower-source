"""Generates Windows .ico asset for PyInstaller builds using Pillow."""

from pathlib import Path
from PIL import Image, ImageDraw

OUT_ICO = Path(__file__).resolve().parent / "assets" / "nova_icon.ico"


def generate_ico() -> None:
    size = 256
    img = Image.new("RGBA", (size, size), (5, 8, 17, 255))
    draw = ImageDraw.Draw(img)

    draw.ellipse((28, 28, 228, 228), outline=(6, 182, 212, 255), width=10)
    draw.ellipse((58, 58, 198, 198), outline=(37, 99, 235, 255), width=8)
    draw.ellipse((96, 96, 160, 160), fill=(6, 182, 212, 255))
    draw.ellipse((112, 112, 144, 144), fill=(5, 8, 17, 255))

    OUT_ICO.parent.mkdir(parents=True, exist_ok=True)
    img.save(OUT_ICO, format="ICO", sizes=[(256, 256), (128, 128), (64, 64), (32, 32), (16, 16)])
    print(f"Generated {OUT_ICO}")


if __name__ == "__main__":
    generate_ico()
