"""Custom QPainter animations for the N.O.V.A. neural core and voice waveform."""

from __future__ import annotations

import math
from collections import deque

from PySide6.QtCore import QPointF, QRectF, Qt, QTimer
from PySide6.QtGui import QColor, QConicalGradient, QPainter, QPen, QRadialGradient
from PySide6.QtWidgets import QWidget


class NovaCoreWidget(QWidget):
    """Animated dark sci-fi central AI core reacting to assistant state & voice energy."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setMinimumSize(260, 260)
        self._state = "SLEEP"
        self._audio_level = 0.0
        self._angle = 0.0

        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(16)  # ~60 FPS

    def set_state(self, state: str) -> None:
        self._state = state
        self.update()

    def set_audio_level(self, level: float) -> None:
        self._audio_level = max(0.0, min(1.0, float(level)))

    def _tick(self) -> None:
        speed = {
            "SLEEP": 0.4,
            "ACTIVE": 1.2,
            "LISTENING": 2.0,
            "THINKING": 3.4,
            "SPEAKING": 2.6,
        }.get(self._state, 1.0)
        self._angle = (self._angle + speed) % 360.0
        self._audio_level *= 0.88
        self.update()

    def paintEvent(self, _event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        w, h = self.width(), self.height()
        cx, cy = w / 2.0, h / 2.0
        radius = min(w, h) * 0.42

        is_sleep = self._state == "SLEEP"
        primary = QColor("#334155") if is_sleep else QColor("#06B6D4")
        secondary = QColor("#1E293B") if is_sleep else QColor("#2563EB")
        energy = 0.15 if is_sleep else (0.35 + self._audio_level * 0.65)

        # Ambient radial core glow
        glow = QRadialGradient(cx, cy, radius * 1.15)
        glow_color = QColor(primary)
        glow_color.setAlphaF(0.18 * energy)
        glow.setColorAt(0.0, glow_color)
        glow.setColorAt(1.0, QColor(5, 8, 17, 0))
        painter.setBrush(glow)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawEllipse(QPointF(cx, cy), radius * 1.15, radius * 1.15)

        # Outer segmented ring
        pen_outer = QPen(primary, 2.0)
        painter.setPen(pen_outer)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        rect_outer = QRectF(cx - radius, cy - radius, radius * 2, radius * 2)
        for i in range(4):
            start_angle = int((self._angle + i * 90) * 16)
            painter.drawArc(rect_outer, start_angle, 58 * 16)

        # Counter-rotating inner telemetry ring
        r_mid = radius * 0.76
        pen_mid = QPen(secondary, 2.5)
        painter.setPen(pen_mid)
        rect_mid = QRectF(cx - r_mid, cy - r_mid, r_mid * 2, r_mid * 2)
        for i in range(3):
            start_angle = int((-self._angle * 1.4 + i * 120) * 16)
            painter.drawArc(rect_mid, start_angle, 82 * 16)

        # Reactive inner energy ring
        r_inner = radius * (0.48 + (0.08 * self._audio_level if not is_sleep else 0.0))
        conical = QConicalGradient(cx, cy, self._angle * 2)
        conical.setColorAt(0.0, primary)
        conical.setColorAt(0.5, secondary)
        conical.setColorAt(1.0, primary)
        painter.setPen(QPen(conical, 3.0))
        painter.drawEllipse(QPointF(cx, cy), r_inner, r_inner)

        # Core nucleus
        core_fill = QRadialGradient(cx, cy, r_inner * 0.65)
        nucleus = QColor("#0EA5E9" if not is_sleep else "#475569")
        nucleus.setAlphaF(0.75 if not is_sleep else 0.3)
        core_fill.setColorAt(0.0, nucleus)
        core_fill.setColorAt(1.0, QColor(8, 12, 23, 210))
        painter.setBrush(core_fill)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawEllipse(QPointF(cx, cy), r_inner * 0.62, r_inner * 0.62)

        # State label centered in nucleus
        painter.setPen(QColor("#E2E8F0") if not is_sleep else QColor("#94A3B8"))
        font = painter.font()
        font.setPointSize(10)
        font.setBold(True)
        painter.setFont(font)
        painter.drawText(
            QRectF(cx - r_inner, cy - 12, r_inner * 2, 24),
            Qt.AlignmentFlag.AlignCenter,
            self._state,
        )


class WaveformWidget(QWidget):
    """Real-time microphone & speech amplitude bar visualizer."""

    def __init__(self, bars: int = 36, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setMinimumHeight(64)
        self.setMaximumHeight(84)
        self._bars = bars
        self._samples: deque[float] = deque([0.05] * bars, maxlen=bars)
        self._active = False
        self._phase = 0.0

        self._timer = QTimer(self)
        self._timer.timeout.connect(self._animate)
        self._timer.start(33)

    def set_active(self, active: bool) -> None:
        self._active = active

    def push_level(self, level: float) -> None:
        clamped = max(0.04, min(1.0, float(level)))
        self._samples.append(clamped)
        self.update()

    def _animate(self) -> None:
        self._phase += 0.25
        if not self._active:
            self._samples.append(0.05)
        else:
            last = self._samples[-1]
            # Smooth decay when idle in active listening
            self._samples.append(max(0.08, last * 0.85 + 0.03 * abs(math.sin(self._phase))))
        self.update()

    def paintEvent(self, _event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        w, h = self.width(), self.height()
        painter.fillRect(0, 0, w, h, QColor("#080C17"))

        count = len(self._samples)
        gap = 4.0
        bar_w = max(2.0, (w - gap * (count + 1)) / count)
        mid_y = h / 2.0

        for idx, amp in enumerate(self._samples):
            bar_h = max(4.0, amp * (h - 14.0))
            x = gap + idx * (bar_w + gap)
            y = mid_y - bar_h / 2.0
            color = QColor("#06B6D4") if self._active else QColor("#334155")
            painter.setBrush(color)
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawRoundedRect(QRectF(x, y, bar_w, bar_h), 2.0, 2.0)
