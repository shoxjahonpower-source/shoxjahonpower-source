"""Settings dialog for N.O.V.A. — DARKNES ULTIMATE."""

from __future__ import annotations

from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from config.settings import NovaConfig, SecretStore, save_config
from core.voice_output import VoiceOutputManager


class SettingsDialog(QDialog):
    """Allows Darknes to configure voice, AI, official messaging, and Windows autostart."""

    def __init__(self, config: NovaConfig, computer_control, parent=None) -> None:
        super().__init__(parent)
        self.config = config
        self.computer_control = computer_control
        self.setWindowTitle("N.O.V.A. — Sozlamalar")
        self.setMinimumWidth(540)
        self.setStyleSheet(
            """
            QDialog { background-color: #070B14; color: #E2E8F0; }
            QLabel { color: #CBD5E1; font-size: 13px; }
            QLineEdit, QComboBox {
                background-color: #0F172A;
                border: 1px solid #1E293B;
                border-radius: 6px;
                padding: 6px 10px;
                color: #F8FAFC;
            }
            QPushButton {
                background-color: #0EA5E9;
                color: #04101D;
                font-weight: 600;
                border-radius: 6px;
                padding: 8px 16px;
            }
            QPushButton:hover { background-color: #38BDF8; }
            QTabWidget::pane { border: 1px solid #1E293B; background-color: #0B1120; }
            QTabBar::tab {
                background: #0F172A; color: #94A3B8; padding: 8px 14px;
                border: 1px solid #1E293B;
            }
            QTabBar::tab:selected { background: #1E293B; color: #38BDF8; }
            """
        )

        layout = QVBoxLayout(self)
        tabs = QTabWidget()

        # Tab 1: General & Voice
        voice_tab = QWidget()
        v_form = QFormLayout(voice_tab)
        self.owner_edit = QLineEdit(config.owner_name)
        self.wake_edit = QLineEdit(config.wake_word)
        self.sleep_edit = QLineEdit(config.sleep_phrase)

        self.stt_combo = QComboBox()
        self.stt_combo.addItems(["hybrid", "vosk_offline", "google_web"])
        self.stt_combo.setCurrentText(config.stt_provider)

        self.tts_combo = QComboBox()
        self.tts_combo.addItems(["edge_tts", "pyttsx3_offline"])
        self.tts_combo.setCurrentText(config.tts_provider)

        self.voice_combo = QComboBox()
        self.voice_combo.addItems(VoiceOutputManager.SUPPORTED_UZBEK_VOICES)
        self.voice_combo.setCurrentText(config.tts_voice)

        self.rate_combo = QComboBox()
        self.rate_combo.addItems(["-20%", "-10%", "+0%", "+10%", "+20%", "+30%"])
        self.rate_combo.setCurrentText(config.tts_rate)

        self.autostart_chk = QCheckBox("Windows yoqilganda N.O.V.A. avtomatik ishga tushsin")
        self.autostart_chk.setChecked(config.autostart_windows)

        v_form.addRow("Egasi ismi:", self.owner_edit)
        v_form.addRow("Uyg'otish iborasi:", self.wake_edit)
        v_form.addRow("Kutish iborasi:", self.sleep_edit)
        v_form.addRow("Nutqni tanish (STT):", self.stt_combo)
        v_form.addRow("Ovoz sintezi (TTS):", self.tts_combo)
        v_form.addRow("O'zbek ovozi:", self.voice_combo)
        v_form.addRow("Nutq tezligi:", self.rate_combo)
        v_form.addRow("", self.autostart_chk)
        tabs.addTab(voice_tab, "Ovoz va Tizim")

        # Tab 2: AI & Security
        ai_tab = QWidget()
        ai_form = QFormLayout(ai_tab)
        self.gemini_model_edit = QLineEdit(config.gemini_model)
        self.gemini_key_edit = QLineEdit()
        self.gemini_key_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.gemini_key_edit.setPlaceholderText(
            "Saqlangan kalitni yangilash uchun kiriting (Windows Credential Manager)"
        )
        ai_info = QLabel(
            "Kalitlar kodingizga yozilmaydi: ular .env yoki Windows Credential Manager'da saqlanadi."
        )
        ai_info.setWordWrap(True)
        ai_form.addRow("Gemini Model:", self.gemini_model_edit)
        ai_form.addRow("GEMINI_API_KEY:", self.gemini_key_edit)
        ai_form.addRow(ai_info)
        tabs.addTab(ai_tab, "AI Miya")

        # Tab 3: Messaging (Telegram & Instagram Official APIs)
        msg_tab = QWidget()
        m_form = QFormLayout(msg_tab)
        self.tg_auto_chk = QCheckBox("Telegram Bot avto-javobini yoqish")
        self.tg_auto_chk.setChecked(config.telegram_auto_reply_enabled)
        self.tg_msg_edit = QLineEdit(config.telegram_auto_reply_message)
        self.tg_token_edit = QLineEdit()
        self.tg_token_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.tg_token_edit.setPlaceholderText("@BotFather rasmiy Bot Token")

        self.ig_auto_chk = QCheckBox("Instagram Business avto-javobini yoqish")
        self.ig_auto_chk.setChecked(config.instagram_auto_reply_enabled)
        self.ig_msg_edit = QLineEdit(config.instagram_auto_reply_message)
        self.ig_page_edit = QLineEdit(config.instagram_page_id)
        self.ig_token_edit = QLineEdit()
        self.ig_token_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.ig_token_edit.setPlaceholderText("Meta Graph API Access Token (parol emas)")

        ig_note = QLabel(
            "Eslatma: Instagram API faqat Facebook Sahifaga ulangan Professional (Business/Creator) "
            "akkauntlarni qo'llab-quvvatlaydi. Shaxsiy akkaunt parollari hech qachon so'ralmaydi."
        )
        ig_note.setWordWrap(True)

        m_form.addRow(self.tg_auto_chk)
        m_form.addRow("Telegram avto-javob:", self.tg_msg_edit)
        m_form.addRow("TELEGRAM_BOT_TOKEN:", self.tg_token_edit)
        m_form.addRow(self.ig_auto_chk)
        m_form.addRow("Instagram avto-javob:", self.ig_msg_edit)
        m_form.addRow("Instagram Page ID:", self.ig_page_edit)
        m_form.addRow("INSTAGRAM_ACCESS_TOKEN:", self.ig_token_edit)
        m_form.addRow(ig_note)
        tabs.addTab(msg_tab, "Telegram / Instagram")

        layout.addWidget(tabs)

        btn_row = QHBoxLayout()
        save_btn = QPushButton("Saqlash")
        cancel_btn = QPushButton("Bekor qilish")
        cancel_btn.setStyleSheet("background-color: #1E293B; color: #E2E8F0;")
        save_btn.clicked.connect(self._save)
        cancel_btn.clicked.connect(self.reject)
        btn_row.addStretch()
        btn_row.addWidget(cancel_btn)
        btn_row.addWidget(save_btn)
        layout.addLayout(btn_row)

    def _save(self) -> None:
        self.config.owner_name = self.owner_edit.text().strip() or "Darknes"
        self.config.wake_word = self.wake_edit.text().strip() or "N.O.V.A., uyg'on!"
        self.config.sleep_phrase = self.sleep_edit.text().strip() or "N.O.V.A., bo'shsan."
        self.config.stt_provider = self.stt_combo.currentText()
        self.config.tts_provider = self.tts_combo.currentText()
        self.config.tts_voice = self.voice_combo.currentText()
        self.config.tts_rate = self.rate_combo.currentText()
        self.config.gemini_model = self.gemini_model_edit.text().strip() or "gemini-2.5-flash"

        self.config.telegram_auto_reply_enabled = self.tg_auto_chk.isChecked()
        self.config.telegram_auto_reply_message = self.tg_msg_edit.text().strip()
        self.config.instagram_auto_reply_enabled = self.ig_auto_chk.isChecked()
        self.config.instagram_auto_reply_message = self.ig_msg_edit.text().strip()
        self.config.instagram_page_id = self.ig_page_edit.text().strip()

        # Store secrets securely in Windows Credential Manager if entered
        if self.gemini_key_edit.text().strip():
            SecretStore.set_secret("GEMINI_API_KEY", self.gemini_key_edit.text().strip())
        if self.tg_token_edit.text().strip():
            SecretStore.set_secret("TELEGRAM_BOT_TOKEN", self.tg_token_edit.text().strip())
        if self.ig_token_edit.text().strip():
            SecretStore.set_secret("INSTAGRAM_ACCESS_TOKEN", self.ig_token_edit.text().strip())

        # Windows autostart requires explicit owner confirmation
        want_autostart = self.autostart_chk.isChecked()
        if want_autostart != self.config.autostart_windows:
            reply = QMessageBox.question(
                self,
                "Tasdiqlash",
                "Windows ishga tushganda N.O.V.A. avtomatik ochilishini tasdiqlaysizmi?",
            )
            if reply == QMessageBox.StandardButton.Yes:
                ok, msg = self.computer_control.set_windows_autostart(
                    want_autostart, owner_confirmed=True
                )
                if ok:
                    self.config.autostart_windows = want_autostart
                else:
                    QMessageBox.warning(self, "Tizim xabari", msg)

        save_config(self.config)
        self.accept()
