"""Futuristic dark sci-fi PySide6 Desktop Dashboard & System Tray for N.O.V.A."""

from __future__ import annotations

import threading
from datetime import datetime

from PySide6.QtCore import Qt, QTimer, Signal, Slot
from PySide6.QtGui import QAction, QIcon, QImage, QPixmap
from PySide6.QtWidgets import (
    QApplication,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QMainWindow,
    QMenu,
    QMessageBox,
    QPushButton,
    QStyle,
    QSystemTrayIcon,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from config.settings import BASE_DIR, NovaConfig
from core.assistant import AssistantState, NovaAssistant
from interface.animations import NovaCoreWidget, WaveformWidget
from interface.memory_dialog import MemoryDialog
from interface.settings import SettingsDialog
from modules.camera import CameraManager
from modules.computer_control import ComputerControl
from modules.instagram import InstagramOfficialClient
from modules.telegram import TelegramBotClient


class NovaDashboard(QMainWindow):
    """Main dark sci-fi desktop window with tray icon, live camera, and voice console."""

    sig_state = Signal(str)
    sig_message = Signal(str, str)
    sig_command = Signal(str, str, bool)
    sig_level = Signal(float)
    sig_confirm_request = Signal(str, object)
    sig_memory_proposal = Signal(str, str)

    def __init__(
        self,
        config: NovaConfig,
        assistant: NovaAssistant,
        computer: ComputerControl,
        camera: CameraManager,
        telegram: TelegramBotClient,
        instagram: InstagramOfficialClient,
    ) -> None:
        super().__init__()
        self.config = config
        self.assistant = assistant
        self.computer = computer
        self.camera = camera
        self.telegram = telegram
        self.instagram = instagram
        self._quitting = False

        self.setWindowTitle("N.O.V.A. — DARKNES ULTIMATE")
        self.resize(1280, 820)
        self._apply_theme()
        self._build_ui()
        self._setup_tray()
        self._connect_signals()

        self._telemetry_timer = QTimer(self)
        self._telemetry_timer.timeout.connect(self._update_telemetry)
        self._telemetry_timer.start(2000)

        self._camera_timer = QTimer(self)
        self._camera_timer.timeout.connect(self._update_camera_frame)

        self._load_persisted_history()
        self._update_telemetry()

    def _apply_theme(self) -> None:
        self.setStyleSheet(
            """
            QMainWindow { background-color: #050811; color: #E2E8F0; }
            QFrame#Panel {
                background-color: #0B1120;
                border: 1px solid #1E293B;
                border-radius: 10px;
            }
            QLabel#Title { font-size: 18px; font-weight: 700; color: #F8FAFC; }
            QLabel#Muted { font-size: 12px; color: #94A3B8; }
            QPushButton {
                background-color: #0F172A;
                border: 1px solid #1E293B;
                border-radius: 7px;
                padding: 8px 14px;
                color: #E2E8F0;
                font-weight: 600;
            }
            QPushButton:hover { border-color: #06B6D4; color: #38BDF8; }
            QPushButton#Primary {
                background-color: #06B6D4;
                border: 1px solid #06B6D4;
                color: #04101D;
            }
            QPushButton#Primary:hover { background-color: #22D3EE; }
            QTextEdit, QListWidget, QLineEdit {
                background-color: #070B14;
                border: 1px solid #1E293B;
                border-radius: 8px;
                color: #E2E8F0;
                padding: 8px;
            }
            """
        )

    def _build_ui(self) -> None:
        root = QWidget()
        main_layout = QVBoxLayout(root)
        main_layout.setContentsMargins(16, 16, 16, 16)
        main_layout.setSpacing(12)

        # Header Telemetry Strip
        header = QFrame()
        header.setObjectName("Panel")
        h_layout = QHBoxLayout(header)
        h_layout.setContentsMargins(16, 10, 16, 10)

        brand = QLabel("N.O.V.A.  ·  DARKNES ULTIMATE")
        brand.setObjectName("Title")
        self.state_label = QLabel("HOLAT: SLEEP")
        self.state_label.setStyleSheet("color: #94A3B8; font-weight: 700;")
        self.mic_status = QLabel("Mikrofon: Faol")
        self.cam_status = QLabel("Kamera: O'chiq")
        self.net_status = QLabel("Internet: Tekshirilmoqda")
        self.sys_status = QLabel("CPU: 0%  ·  RAM: 0%")

        memory_btn = QPushButton("Xotira")
        memory_btn.clicked.connect(self._open_memory_dialog)
        settings_btn = QPushButton("Sozlamalar")
        settings_btn.clicked.connect(self._open_settings)
        tray_btn = QPushButton("Treyga yashirish")
        tray_btn.clicked.connect(self.hide)

        h_layout.addWidget(brand)
        h_layout.addStretch()
        for lbl in (
            self.state_label,
            self.mic_status,
            self.cam_status,
            self.net_status,
            self.sys_status,
        ):
            lbl.setStyleSheet(lbl.styleSheet() + " margin-right: 14px; font-size: 12px;")
            h_layout.addWidget(lbl)
        h_layout.addWidget(memory_btn)
        h_layout.addWidget(settings_btn)
        h_layout.addWidget(tray_btn)
        main_layout.addWidget(header)

        # Body 3-Column Layout
        body = QHBoxLayout()
        body.setSpacing(12)

        # Left Column: Core + Voice Controls + Waveform
        left_panel = QFrame()
        left_panel.setObjectName("Panel")
        left_panel.setMinimumWidth(340)
        left_panel.setMaximumWidth(380)
        l_layout = QVBoxLayout(left_panel)
        l_layout.setContentsMargins(16, 16, 16, 16)

        self.core_widget = NovaCoreWidget()
        self.waveform = WaveformWidget()

        ctrl_row1 = QHBoxLayout()
        self.wake_btn = QPushButton("Uyg'otish")
        self.wake_btn.setObjectName("Primary")
        self.wake_btn.clicked.connect(self._toggle_sleep_active)
        self.mic_btn = QPushButton("Mikrofonni o'chirish")
        self.mic_btn.clicked.connect(self._toggle_mic)
        ctrl_row1.addWidget(self.wake_btn)
        ctrl_row1.addWidget(self.mic_btn)

        ctrl_row2 = QHBoxLayout()
        self.interrupt_btn = QPushButton("Nutqni to'xtatish")
        self.interrupt_btn.clicked.connect(self.assistant.interrupt_speech)
        self.cam_btn = QPushButton("Kamerani yoqish")
        self.cam_btn.clicked.connect(self._toggle_camera)
        ctrl_row2.addWidget(self.interrupt_btn)
        ctrl_row2.addWidget(self.cam_btn)

        slogan = QLabel("YOUR WORLD. YOUR INTELLIGENCE. YOUR N.O.V.A.")
        slogan.setObjectName("Muted")
        slogan.setAlignment(Qt.AlignmentFlag.AlignCenter)

        l_layout.addWidget(self.core_widget, 1)
        l_layout.addWidget(self.waveform)
        l_layout.addLayout(ctrl_row1)
        l_layout.addLayout(ctrl_row2)
        l_layout.addWidget(slogan)
        body.addWidget(left_panel)

        # Center Column: AI Conversation Window
        center_panel = QFrame()
        center_panel.setObjectName("Panel")
        c_layout = QVBoxLayout(center_panel)
        c_layout.setContentsMargins(16, 16, 16, 16)

        c_title = QLabel("AI Suhbat Oynasi (O'zbekcha)")
        c_title.setStyleSheet("font-size: 14px; font-weight: 700; color: #38BDF8;")
        self.chat_view = QTextEdit()
        self.chat_view.setReadOnly(True)

        input_row = QHBoxLayout()
        self.prompt_input = QLineEdit()
        self.prompt_input.setPlaceholderText(
            "Buyruq yoki savol yozing (masalan: N.O.V.A., uyg'on! yoki Vaqtni ayt)..."
        )
        self.prompt_input.returnPressed.connect(self._send_text_command)
        send_btn = QPushButton("Yuborish")
        send_btn.setObjectName("Primary")
        send_btn.clicked.connect(self._send_text_command)
        input_row.addWidget(self.prompt_input, 1)
        input_row.addWidget(send_btn)

        c_layout.addWidget(c_title)
        c_layout.addWidget(self.chat_view, 1)
        c_layout.addLayout(input_row)
        body.addWidget(center_panel, 2)

        # Right Column: Camera Vision + Command History
        right_panel = QFrame()
        right_panel.setObjectName("Panel")
        right_panel.setMinimumWidth(340)
        r_layout = QVBoxLayout(right_panel)
        r_layout.setContentsMargins(16, 16, 16, 16)

        cam_hdr = QLabel("Kompyuter Ko'rishi (OpenCV + MediaPipe)")
        cam_hdr.setStyleSheet("font-size: 14px; font-weight: 700; color: #38BDF8;")
        self.camera_preview = QLabel("Kamera o'chiq.\nMaxfiylik: ruxsatsiz yozuv olinmaydi.")
        self.camera_preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.camera_preview.setMinimumHeight(210)
        self.camera_preview.setStyleSheet(
            "background-color: #050811; border: 1px solid #1E293B; border-radius: 8px; color: #64748B;"
        )

        vision_btns = QHBoxLayout()
        self.vision_desc_btn = QPushButton("Kamerani AI tahlil qilsin")
        self.vision_desc_btn.clicked.connect(self._describe_camera)
        self.enroll_face_btn = QPushButton("Yuzni saqlash")
        self.enroll_face_btn.clicked.connect(self._enroll_face)
        vision_btns.addWidget(self.vision_desc_btn)
        vision_btns.addWidget(self.enroll_face_btn)

        self.gesture_label = QLabel("Jestlar: Kutilmoqda")
        self.gesture_label.setObjectName("Muted")

        hist_hdr = QLabel("Buyruqlar Tarixi")
        hist_hdr.setStyleSheet("font-size: 14px; font-weight: 700; color: #38BDF8; margin-top: 8px;")
        self.history_list = QListWidget()

        r_layout.addWidget(cam_hdr)
        r_layout.addWidget(self.camera_preview)
        r_layout.addLayout(vision_btns)
        r_layout.addWidget(self.gesture_label)
        r_layout.addWidget(hist_hdr)
        r_layout.addWidget(self.history_list, 1)
        body.addWidget(right_panel, 1)

        main_layout.addLayout(body, 1)
        self.setCentralWidget(root)

    def _setup_tray(self) -> None:
        icon_path = BASE_DIR / "assets" / "nova_icon.svg"
        icon = (
            QIcon(str(icon_path))
            if icon_path.exists()
            else self.style().standardIcon(QStyle.StandardPixmap.SP_ComputerIcon)
        )
        self.setWindowIcon(icon)

        self.tray = QSystemTrayIcon(icon, self)
        menu = QMenu()
        show_act = QAction("Oynani ochish", self)
        show_act.triggered.connect(self._show_window)
        wake_act = QAction("Uyg'otish / Kutish", self)
        wake_act.triggered.connect(self._toggle_sleep_active)
        quit_act = QAction("Xavfsiz chiqish", self)
        quit_act.triggered.connect(self._safe_quit)
        menu.addAction(show_act)
        menu.addAction(wake_act)
        menu.addSeparator()
        menu.addAction(quit_act)
        self.tray.setContextMenu(menu)
        self.tray.activated.connect(self._on_tray_activated)
        self.tray.show()

    def _connect_signals(self) -> None:
        self.sig_state.connect(self._on_state_updated)
        self.sig_message.connect(self._append_chat)
        self.sig_command.connect(self._append_command)
        self.sig_level.connect(self._on_audio_level)
        self.sig_confirm_request.connect(self._show_confirm_dialog)
        self.sig_memory_proposal.connect(self._prompt_memory_approval)

        self.assistant.on_state_change = lambda st: self.sig_state.emit(st.value)
        self.assistant.on_message = lambda s, t: self.sig_message.emit(s, t)
        self.assistant.on_command_log = lambda c, a, ok: self.sig_command.emit(c, a, ok)
        self.assistant.on_audio_level = lambda lv: self.sig_level.emit(lv)
        self.assistant.on_memory_proposal = lambda f, c: self.sig_memory_proposal.emit(f, c)

    def ask_owner_confirmation(self, prompt: str) -> bool:
        """Thread-safe confirmation dialog requested by CommandRouter."""
        result_holder = {"approved": False}
        done_event = threading.Event()
        self.sig_confirm_request.emit(prompt, (result_holder, done_event))
        done_event.wait(timeout=30.0)
        return result_holder["approved"]

    @Slot(str, object)
    def _show_confirm_dialog(self, prompt: str, holder_tuple: object) -> None:
        result_holder, done_event = holder_tuple  # type: ignore[misc]
        reply = QMessageBox.question(
            self,
            "N.O.V.A. — Ruxsat so'rovi",
            prompt,
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        result_holder["approved"] = reply == QMessageBox.StandardButton.Yes
        done_event.set()

    @Slot(str)
    def _on_state_updated(self, state_str: str) -> None:
        self.core_widget.set_state(state_str)
        is_sleep = state_str == AssistantState.SLEEP.value
        self.waveform.set_active(not is_sleep and not self.config.microphone_muted)
        color = "#94A3B8" if is_sleep else "#06B6D4"
        self.state_label.setText(f"HOLAT: {state_str}")
        self.state_label.setStyleSheet(f"color: {color}; font-weight: 700; font-size: 12px;")
        self.wake_btn.setText("Uyg'otish" if is_sleep else "Kutish rejimi")

    @Slot(str, str)
    def _append_chat(self, sender: str, text: str) -> None:
        stamp = datetime.now().strftime("%H:%M:%S")
        color = "#38BDF8" if sender == "N.O.V.A." else "#E2E8F0"
        self.chat_view.append(f"<span style='color:#64748B'>[{stamp}]</span> "
                              f"<b style='color:{color}'>{sender}:</b> {text}")

    @Slot(str, str, bool)
    def _append_command(self, cmd: str, action: str, ok: bool) -> None:
        stamp = datetime.now().strftime("%H:%M:%S")
        mark = "OK" if ok else "RAD"
        self.history_list.insertItem(0, f"[{stamp}] {mark} · {action} — {cmd}")

    @Slot(float)
    def _on_audio_level(self, level: float) -> None:
        self.core_widget.set_audio_level(level)
        self.waveform.push_level(level)

    def _toggle_sleep_active(self) -> None:
        if self.assistant.state == AssistantState.SLEEP:
            threading.Thread(target=self.assistant.wake_up, daemon=True).start()
        else:
            threading.Thread(target=self.assistant.go_to_sleep, daemon=True).start()

    def _toggle_mic(self) -> None:
        muted = not self.config.microphone_muted
        self.assistant.set_mic_muted(muted)
        self.mic_btn.setText("Mikrofonni yoqish" if muted else "Mikrofonni o'chirish")
        self.mic_status.setText("Mikrofon: O'chiq (Mute)" if muted else "Mikrofon: Faol")

    def _toggle_camera(self) -> None:
        if self.camera.is_active:
            self.camera.stop()
            self._camera_timer.stop()
            self.cam_btn.setText("Kamerani yoqish")
            self.cam_status.setText("Kamera: O'chiq")
            self.camera_preview.setPixmap(QPixmap())
            self.camera_preview.setText("Kamera o'chiq.\nMaxfiylik: ruxsatsiz yozuv olinmaydi.")
        else:
            ok, msg = self.camera.start()
            if ok:
                self._camera_timer.start(45)
                self.cam_btn.setText("Kamerani o'chirish")
                self.cam_status.setText("Kamera: YOQILGAN")
            else:
                QMessageBox.warning(self, "Kamera", msg)

    def _update_camera_frame(self) -> None:
        analysis = self.camera.read_and_process(detect_hands=self.config.hand_gestures_enabled)
        if not analysis.camera_active or analysis.frame_rgb is None:
            return
        h, w, ch = analysis.frame_rgb.shape
        qimg = QImage(analysis.frame_rgb.data, w, h, ch * w, QImage.Format.Format_RGB888)
        pix = QPixmap.fromImage(qimg).scaled(
            self.camera_preview.size(),
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        )
        self.camera_preview.setPixmap(pix)
        gestures_str = ", ".join(analysis.hand_gestures) if analysis.hand_gestures else "Aniqlanmadi"
        owner_tag = " · Egasi: Darknes" if analysis.recognized_owner else ""
        self.gesture_label.setText(
            f"Yuzlar: {analysis.faces_count}{owner_tag} · Jestlar: {gestures_str}"
        )

    def _describe_camera(self) -> None:
        if not self.camera.is_active:
            QMessageBox.information(self, "Kamera", "Avval kamerani yoqing.")
            return
        jpeg = self.camera.capture_jpeg_snapshot()
        if not jpeg:
            QMessageBox.warning(self, "Kamera", "Tasvir olib bo'lmadi.")
            return
        self._append_chat(self.config.owner_name, "[Kameradagi tasvirni tahlil qilish so'raldi]")

        def _worker() -> None:
            reply = self.assistant.ai_brain.analyze_frame(jpeg)
            self.sig_message.emit("N.O.V.A.", reply.text)
            self.assistant.voice_output.speak(reply.text)

        threading.Thread(target=_worker, daemon=True).start()

    def _enroll_face(self) -> None:
        if not self.camera.is_active:
            QMessageBox.information(self, "Yuzni saqlash", "Avval kamerani yoqing.")
            return
        reply = QMessageBox.question(
            self,
            "Mahalliy yuzni tanish roziligi",
            "Yuzingiz faqat ushbu kompyuterda mahalliy tanib olish uchun saqlansinmi?",
        )
        ok, msg = self.camera.enroll_owner_face(
            consent_confirmed=(reply == QMessageBox.StandardButton.Yes)
        )
        QMessageBox.information(self, "Yuzni saqlash", msg)

    def _send_text_command(self) -> None:
        text = self.prompt_input.text().strip()
        if not text:
            return
        self.prompt_input.clear()
        threading.Thread(
            target=self.assistant.handle_user_utterance, args=(text,), daemon=True
        ).start()

    def _update_telemetry(self) -> None:
        t = self.computer.get_system_telemetry()
        net = "Onlayn" if t["internet_connected"] else "Oflayn"
        self.net_status.setText(f"Internet: {net}")
        self.sys_status.setText(
            f"CPU: {t['cpu_percent']:.0f}%  ·  RAM: {t['ram_percent']:.0f}% ({t['ram_used_gb']}/{t['ram_total_gb']} GB)"
        )

    def _load_persisted_history(self) -> None:
        turns = self.assistant.ai_brain.memory_store.conversation_history[-20:]
        for turn in turns:
            sender = self.config.owner_name if turn.role == "user" else "N.O.V.A."
            color = "#38BDF8" if sender == "N.O.V.A." else "#E2E8F0"
            self.chat_view.append(
                f"<span style='color:#64748B'>[{turn.timestamp}]</span> "
                f"<b style='color:{color}'>{sender}:</b> {turn.text}"
            )

    @Slot(str, str)
    def _prompt_memory_approval(self, fact: str, category: str) -> None:
        reply = QMessageBox.question(
            self,
            "N.O.V.A. — Xotiraga saqlash",
            f"Quyidagi ma'lumot doimiy xotiraga saqlansinmi?\n\n[{category}] {fact}",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if reply == QMessageBox.StandardButton.Yes:
            self.assistant.ai_brain.approve_and_save_preference(fact, category=category)

    def _open_memory_dialog(self) -> None:
        dlg = MemoryDialog(self.assistant.ai_brain.memory_store, self)
        dlg.exec()

    def _open_settings(self) -> None:
        dlg = SettingsDialog(self.config, self.computer, self)
        if dlg.exec():
            self.assistant.ai_brain.reset_client()
            self.assistant.voice_output.provider = self.config.tts_provider
            self.assistant.voice_output.voice = self.config.tts_voice
            self.assistant.voice_output.rate = self.config.tts_rate
            self.assistant.voice_input.set_provider(self.config.stt_provider)
            self.telegram.bot_token = self.config.get_telegram_bot_token()
            self.telegram.auto_reply_enabled = self.config.telegram_auto_reply_enabled
            self.telegram.auto_reply_message = self.config.telegram_auto_reply_message
            self.instagram.access_token = self.config.get_instagram_access_token()
            self.instagram.page_id = self.config.instagram_page_id
            self.instagram.auto_reply_enabled = self.config.instagram_auto_reply_enabled
            self.instagram.auto_reply_message = self.config.instagram_auto_reply_message

    def _show_window(self) -> None:
        self.showNormal()
        self.activateWindow()

    def _on_tray_activated(self, reason) -> None:
        if reason == QSystemTrayIcon.ActivationReason.Trigger:
            self._show_window()

    def closeEvent(self, event) -> None:  # noqa: N802
        if not self._quitting:
            event.ignore()
            self.hide()
            self.tray.showMessage(
                "N.O.V.A. — DARKNES ULTIMATE",
                "Yordamchi fonda ishlashda davom etmoqda.",
                QSystemTrayIcon.MessageIcon.Information,
                2500,
            )
        else:
            event.accept()

    def _safe_quit(self) -> None:
        self._quitting = True
        self._telemetry_timer.stop()
        self._camera_timer.stop()
        self.camera.stop()
        self.telegram.stop_polling()
        self.instagram.stop_webhook_server()
        self.assistant.stop()
        self.tray.hide()
        QApplication.quit()
