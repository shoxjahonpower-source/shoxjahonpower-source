"""PySide6 futuristic desktop UI package for N.O.V.A."""

from .animations import NovaCoreWidget, WaveformWidget
from .dashboard import NovaDashboard
from .memory_dialog import MemoryDialog
from .settings import SettingsDialog

__all__ = ["MemoryDialog", "NovaCoreWidget", "NovaDashboard", "SettingsDialog", "WaveformWidget"]
