"""PySide6 dialog to view, add, edit, and delete N.O.V.A.'s persistent memories & history."""

from __future__ import annotations

from PySide6.QtWidgets import (
    QComboBox,
    QDialog,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
)

from core.memory_store import MemoryStore


class MemoryDialog(QDialog):
    """Allows Darknes to inspect, add, edit, and delete saved memories and clear chat history."""

    def __init__(self, memory_store: MemoryStore, parent=None) -> None:
        super().__init__(parent)
        self.memory_store = memory_store
        self.setWindowTitle("N.O.V.A. — Xotira va Suhbatlar Boshqaruvi")
        self.setMinimumSize(620, 480)
        self.setStyleSheet(
            """
            QDialog { background-color: #070B14; color: #E2E8F0; }
            QLabel { color: #CBD5E1; font-size: 13px; }
            QListWidget, QLineEdit, QComboBox {
                background-color: #0B1120;
                border: 1px solid #1E293B;
                border-radius: 6px;
                color: #F8FAFC;
                padding: 6px;
            }
            QPushButton {
                background-color: #0F172A;
                border: 1px solid #1E293B;
                color: #E2E8F0;
                font-weight: 600;
                border-radius: 6px;
                padding: 7px 14px;
            }
            QPushButton:hover { border-color: #06B6D4; color: #38BDF8; }
            QPushButton#Primary { background-color: #06B6D4; color: #04101D; border: none; }
            """
        )

        layout = QVBoxLayout(self)
        title = QLabel("Saqlangan Xotiralar (Afzalliklar, Loyiha tafsilotlari, Eslatmalar)")
        title.setStyleSheet("font-size: 14px; font-weight: 700; color: #38BDF8;")
        layout.addWidget(title)

        self.mem_list = QListWidget()
        layout.addWidget(self.mem_list, 1)

        add_row = QHBoxLayout()
        self.cat_combo = QComboBox()
        self.cat_combo.addItems(["preference", "project", "personal", "note"])
        self.new_mem_edit = QLineEdit()
        self.new_mem_edit.setPlaceholderText("Yangi xotira yozuvini kiriting...")
        add_btn = QPushButton("Qo'shish")
        add_btn.setObjectName("Primary")
        add_btn.clicked.connect(self._add_memory)
        add_row.addWidget(self.cat_combo)
        add_row.addWidget(self.new_mem_edit, 1)
        add_row.addWidget(add_btn)
        layout.addLayout(add_row)

        actions = QHBoxLayout()
        edit_btn = QPushButton("Tahrirlash")
        edit_btn.clicked.connect(self._edit_selected)
        del_btn = QPushButton("O'chirish")
        del_btn.clicked.connect(self._delete_selected)
        clear_hist_btn = QPushButton("Suhbat tarixini tozalash")
        clear_hist_btn.clicked.connect(self._clear_history)
        close_btn = QPushButton("Yopish")
        close_btn.clicked.connect(self.accept)

        actions.addWidget(edit_btn)
        actions.addWidget(del_btn)
        actions.addWidget(clear_hist_btn)
        actions.addStretch()
        actions.addWidget(close_btn)
        layout.addLayout(actions)

        self._refresh()

    def _refresh(self) -> None:
        self.mem_list.clear()
        for item in self.memory_store.list_memories():
            row = QListWidgetItem(f"[{item.category}] {item.content}  ({item.updated_at})")
            row.setData(256, item.id)
            self.mem_list.addItem(row)

    def _add_memory(self) -> None:
        text = self.new_mem_edit.text().strip()
        if not text:
            return
        self.memory_store.add_memory(text, category=self.cat_combo.currentText())
        self.new_mem_edit.clear()
        self._refresh()

    def _edit_selected(self) -> None:
        row = self.mem_list.currentItem()
        if not row:
            return
        mem_id = row.data(256)
        current = next((m for m in self.memory_store.list_memories() if m.id == mem_id), None)
        if not current:
            return
        new_text, ok = QInputDialog.getText(
            self, "Xotirani tahrirlash", "Matn:", text=current.content
        )
        if ok and new_text.strip():
            self.memory_store.update_memory(mem_id, new_text.strip())
            self._refresh()

    def _delete_selected(self) -> None:
        row = self.mem_list.currentItem()
        if not row:
            return
        mem_id = row.data(256)
        reply = QMessageBox.question(
            self, "Tasdiqlash", "Tanlangan xotira yozuvi o'chirilsinmi?"
        )
        if reply == QMessageBox.StandardButton.Yes:
            self.memory_store.delete_memory(mem_id)
            self._refresh()

    def _clear_history(self) -> None:
        reply = QMessageBox.question(
            self, "Tasdiqlash", "Barcha suhbat tarixi tozalansinmi?"
        )
        if reply == QMessageBox.StandardButton.Yes:
            self.memory_store.clear_history()
            QMessageBox.information(self, "Xotira", "Suhbat tarixi tozalandi.")
