"""Centralized configuration and secure credential storage for N.O.V.A."""

from __future__ import annotations

import json
import os
import shutil
import sys
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

try:
    from dotenv import load_dotenv
except ImportError:  # pragma: no cover
    def load_dotenv(*_args: Any, **_kwargs: Any) -> bool:
        return False

try:
    import keyring
    from keyring.errors import KeyringError
except Exception:  # pragma: no cover
    keyring = None
    KeyringError = Exception

IS_FROZEN = bool(getattr(sys, "frozen", False))
SOURCE_ROOT = Path(__file__).resolve().parent.parent
BUNDLE_DIR = Path(getattr(sys, "_MEIPASS", SOURCE_ROOT))

if IS_FROZEN:
    _local_app_data = os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA")
    DATA_DIR = (
        Path(_local_app_data) / "NOVA_Darknes_Ultimate"
        if _local_app_data
        else Path(sys.executable).resolve().parent / "nova_data"
    )
else:
    DATA_DIR = SOURCE_ROOT

BASE_DIR = BUNDLE_DIR
CONFIG_DIR = DATA_DIR / "config"
BUNDLED_CONFIG_DIR = BUNDLE_DIR / "config"
RUNTIME_CONFIG_PATH = CONFIG_DIR / "runtime_settings.json"
PREFERENCES_PATH = CONFIG_DIR / "preferences.json"
ALLOWLIST_PATH = (
    CONFIG_DIR / "allowlist.json"
    if (CONFIG_DIR / "allowlist.json").exists()
    else BUNDLED_CONFIG_DIR / "allowlist.json"
)

KEYRING_SERVICE = "NOVA_DARKNES_ULTIMATE"


def resolve_asset_path(relative_path: str | Path) -> Path:
    """Prefers writable DATA_DIR asset (e.g. downloaded Vosk model), falling back to BUNDLE_DIR."""
    rel = Path(relative_path)
    data_candidate = DATA_DIR / rel
    if data_candidate.exists():
        return data_candidate
    return BUNDLE_DIR / rel


def ensure_writable_config_seeded() -> None:
    """Seeds writable config files from bundled defaults on first frozen launch."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    for filename in ("memory.json", "preferences.json"):
        target = CONFIG_DIR / filename
        bundled = BUNDLED_CONFIG_DIR / filename
        if not target.exists() and bundled.exists():
            try:
                shutil.copy2(bundled, target)
            except Exception:
                pass


class SecretStore:
    """Reads secrets from environment variables first, then Windows Credential Manager."""

    @staticmethod
    def get_secret(name: str, default: str = "") -> str:
        env_val = os.environ.get(name, "").strip()
        if env_val:
            return env_val
        if keyring is not None:
            try:
                stored = keyring.get_password(KEYRING_SERVICE, name)
                if stored:
                    return stored.strip()
            except KeyringError:
                pass
            except Exception:
                pass
        return default

    @staticmethod
    def set_secret(name: str, value: str) -> bool:
        cleaned = value.strip()
        if not cleaned:
            return SecretStore.delete_secret(name)
        if keyring is not None:
            try:
                keyring.set_password(KEYRING_SERVICE, name, cleaned)
                return True
            except Exception:
                return False
        return False

    @staticmethod
    def delete_secret(name: str) -> bool:
        if keyring is not None:
            try:
                keyring.delete_password(KEYRING_SERVICE, name)
                return True
            except Exception:
                return False
        return False


@dataclass
class NovaConfig:
    owner_name: str = "Darknes"
    language: str = "uz"
    wake_word: str = "N.O.V.A., uyg'on!"
    sleep_phrase: str = "N.O.V.A., bo'shsan."
    gemini_model: str = "gemini-2.5-flash"

    stt_provider: str = "hybrid"  # vosk_offline | google_web | hybrid
    vosk_model_path: str = "assets/models/vosk-model-small-uz-0.22"
    tts_provider: str = "edge_tts"  # edge_tts | pyttsx3_offline
    tts_voice: str = "uz-UZ-MadinaNeural"
    tts_rate: str = "+0%"

    microphone_muted: bool = False
    camera_enabled: bool = False
    face_recognition_consent: bool = False
    hand_gestures_enabled: bool = True

    telegram_auto_reply_enabled: bool = False
    telegram_auto_reply_message: str = (
        "Darknes online emas. Bir oz kuting! Javob berdi: N.O.V.A."
    )
    instagram_page_id: str = ""
    instagram_webhook_port: int = 8765
    instagram_auto_reply_enabled: bool = False
    instagram_auto_reply_message: str = (
        "Darknes online emas. Bir oz kuting! Javob berdi: N.O.V.A."
    )

    autostart_windows: bool = False
    extra_wake_aliases: list[str] = field(
        default_factory=lambda: [
            "nova uygon",
            "nova uyg'on",
            "n o v a uygon",
            "nova uygan",
            "nova",
        ]
    )
    extra_sleep_aliases: list[str] = field(
        default_factory=lambda: [
            "nova boshsan",
            "nova bo'shsan",
            "n o v a boshsan",
            "nova uxlagin",
        ]
    )

    def get_gemini_api_key(self) -> str:
        return SecretStore.get_secret("GEMINI_API_KEY")

    def get_telegram_bot_token(self) -> str:
        return SecretStore.get_secret("TELEGRAM_BOT_TOKEN")

    def get_instagram_access_token(self) -> str:
        return SecretStore.get_secret("INSTAGRAM_ACCESS_TOKEN")

    def get_instagram_verify_token(self) -> str:
        return SecretStore.get_secret("INSTAGRAM_WEBHOOK_VERIFY_TOKEN")


def _parse_bool(raw: str | None, fallback: bool) -> bool:
    if raw is None:
        return fallback
    return raw.strip().lower() in {"1", "true", "yes", "ha", "on"}


def load_config() -> NovaConfig:
    ensure_writable_config_seeded()
    for env_candidate in (
        DATA_DIR / ".env",
        Path(sys.executable).resolve().parent / ".env",
        BUNDLE_DIR / ".env",
    ):
        if env_candidate.exists():
            load_dotenv(env_candidate)
            break
    cfg = NovaConfig()

    if RUNTIME_CONFIG_PATH.exists():
        try:
            data = json.loads(RUNTIME_CONFIG_PATH.read_text(encoding="utf-8"))
            for key, value in data.items():
                if hasattr(cfg, key):
                    setattr(cfg, key, value)
        except Exception:
            pass

    # Environment overrides (non-secret settings)
    cfg.owner_name = os.environ.get("NOVA_OWNER_NAME", cfg.owner_name)
    cfg.language = os.environ.get("NOVA_LANGUAGE", cfg.language)
    cfg.wake_word = os.environ.get("NOVA_WAKE_WORD", cfg.wake_word)
    cfg.sleep_phrase = os.environ.get("NOVA_SLEEP_PHRASE", cfg.sleep_phrase)
    cfg.gemini_model = os.environ.get("GEMINI_MODEL", cfg.gemini_model)
    cfg.stt_provider = os.environ.get("NOVA_STT_PROVIDER", cfg.stt_provider)
    cfg.vosk_model_path = os.environ.get("NOVA_VOSK_MODEL_PATH", cfg.vosk_model_path)
    cfg.tts_provider = os.environ.get("NOVA_TTS_PROVIDER", cfg.tts_provider)
    cfg.tts_voice = os.environ.get("NOVA_TTS_VOICE", cfg.tts_voice)
    cfg.tts_rate = os.environ.get("NOVA_TTS_RATE", cfg.tts_rate)
    cfg.instagram_page_id = os.environ.get("INSTAGRAM_PAGE_ID", cfg.instagram_page_id)

    if "TELEGRAM_AUTO_REPLY_ENABLED" in os.environ:
        cfg.telegram_auto_reply_enabled = _parse_bool(
            os.environ.get("TELEGRAM_AUTO_REPLY_ENABLED"),
            cfg.telegram_auto_reply_enabled,
        )
    if "TELEGRAM_AUTO_REPLY_MESSAGE" in os.environ:
        cfg.telegram_auto_reply_message = os.environ["TELEGRAM_AUTO_REPLY_MESSAGE"]
    if "INSTAGRAM_AUTO_REPLY_ENABLED" in os.environ:
        cfg.instagram_auto_reply_enabled = _parse_bool(
            os.environ.get("INSTAGRAM_AUTO_REPLY_ENABLED"),
            cfg.instagram_auto_reply_enabled,
        )
    if "INSTAGRAM_AUTO_REPLY_MESSAGE" in os.environ:
        cfg.instagram_auto_reply_message = os.environ["INSTAGRAM_AUTO_REPLY_MESSAGE"]

    return cfg


def save_config(cfg: NovaConfig) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    RUNTIME_CONFIG_PATH.write_text(
        json.dumps(asdict(cfg), indent=2, ensure_ascii=False),
        encoding="utf-8",
    )


def load_allowlist() -> dict[str, Any]:
    if not ALLOWLIST_PATH.exists():
        return {"allowed_apps": {}, "allowed_urls": {}, "sensitive_actions": []}
    return json.loads(ALLOWLIST_PATH.read_text(encoding="utf-8"))
