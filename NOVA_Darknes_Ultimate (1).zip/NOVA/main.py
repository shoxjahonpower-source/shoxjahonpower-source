"""Entry point for N.O.V.A. — DARKNES ULTIMATE Windows Desktop Application."""

from __future__ import annotations

import logging
import sys
from pathlib import Path

# Ensure NOVA root is importable when frozen or launched directly
NOVA_ROOT = Path(__file__).resolve().parent
if str(NOVA_ROOT) not in sys.path:
    sys.path.insert(0, str(NOVA_ROOT))

from PySide6.QtWidgets import QApplication

from config.settings import BUNDLE_DIR, DATA_DIR, load_config, resolve_asset_path
from core.ai_brain import AiBrain
from core.assistant import NovaAssistant
from core.command_router import CommandRouter
from core.voice_input import VoiceInputManager
from core.voice_output import VoiceOutputManager
from core.wake_word import WakeWordDetector
from interface.dashboard import NovaDashboard
from modules.browser_control import BrowserControl
from modules.camera import CameraManager
from modules.computer_control import ComputerControl
from modules.instagram import InstagramOfficialClient
from modules.telegram import TelegramBotClient

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)


def run_smoke_test() -> int:
    """Verifies frozen bundle assets, writable config seeding, and core modules."""
    cfg = load_config()
    allowlist_path = resolve_asset_path("config/allowlist.json")
    icon_path = BUNDLE_DIR / "assets" / "nova_icon.svg"
    if not allowlist_path.exists():
        print(f"SMOKE TEST FAILED: missing {allowlist_path}")
        return 1
    if not icon_path.exists():
        print(f"SMOKE TEST FAILED: missing {icon_path}")
        return 1
    computer = ComputerControl()
    browser = BrowserControl()
    router = CommandRouter(computer_control=computer, browser_control=browser, owner_name=cfg.owner_name)
    res = router.route("Vaqtni ayt.")
    if not res.handled or not res.success:
        print("SMOKE TEST FAILED: command router failed on Vaqtni ayt.")
        return 1
    brain = AiBrain(cfg)
    if brain.memory_store is None:
        print("SMOKE TEST FAILED: memory store not initialized")
        return 1
    print(f"SMOKE TEST OK | DATA_DIR={DATA_DIR} | BUNDLE_DIR={BUNDLE_DIR}")
    return 0


def main() -> int:
    if "--smoke-test" in sys.argv:
        return run_smoke_test()

    app = QApplication(sys.argv)
    app.setApplicationName("N.O.V.A. — DARKNES ULTIMATE")
    app.setQuitOnLastWindowClosed(False)

    cfg = load_config()
    computer = ComputerControl()
    browser = BrowserControl()

    vosk_dir = resolve_asset_path(cfg.vosk_model_path)
    wake_detector = WakeWordDetector(
        wake_phrase=cfg.wake_word,
        sleep_phrase=cfg.sleep_phrase,
        vosk_model_path=vosk_dir,
        extra_wake_aliases=cfg.extra_wake_aliases,
        extra_sleep_aliases=cfg.extra_sleep_aliases,
    )
    voice_input = VoiceInputManager(
        provider=cfg.stt_provider,
        vosk_model_path=vosk_dir,
        language="uz-UZ",
    )
    voice_output = VoiceOutputManager(
        provider=cfg.tts_provider,
        voice=cfg.tts_voice,
        rate=cfg.tts_rate,
    )
    ai_brain = AiBrain(cfg)
    camera = CameraManager(face_recognition_consent=cfg.face_recognition_consent)

    telegram_client = TelegramBotClient(
        bot_token=cfg.get_telegram_bot_token(),
        auto_reply_enabled=cfg.telegram_auto_reply_enabled,
        auto_reply_message=cfg.telegram_auto_reply_message,
    )
    instagram_client = InstagramOfficialClient(
        access_token=cfg.get_instagram_access_token(),
        page_id=cfg.instagram_page_id,
        verify_token=cfg.get_instagram_verify_token(),
        auto_reply_enabled=cfg.instagram_auto_reply_enabled,
        auto_reply_message=cfg.instagram_auto_reply_message,
    )

    command_router = CommandRouter(
        computer_control=computer,
        browser_control=browser,
        owner_name=cfg.owner_name,
    )

    assistant = NovaAssistant(
        config=cfg,
        wake_detector=wake_detector,
        voice_input=voice_input,
        voice_output=voice_output,
        ai_brain=ai_brain,
        command_router=command_router,
    )

    dashboard = NovaDashboard(
        config=cfg,
        assistant=assistant,
        computer=computer,
        camera=camera,
        telegram=telegram_client,
        instagram=instagram_client,
    )
    command_router.confirm_callback = dashboard.ask_owner_confirmation

    # Start official messaging services only if tokens are configured
    if telegram_client.bot_token:
        telegram_client.start_polling()
    if instagram_client.access_token and instagram_client.page_id:
        instagram_client.start_webhook_server(port=cfg.instagram_webhook_port)

    assistant.start()
    dashboard.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
