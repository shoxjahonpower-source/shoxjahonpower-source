# N.O.V.A. — DARKNES ULTIMATE

> **YOUR WORLD. YOUR INTELLIGENCE. YOUR N.O.V.A.**
> Windows 10 va Windows 11 uchun o'zbek tilidagi shaxsiy AI yordamchi.

---

## 1. O'rnatish qo'llanmasi (O'zbek tilida)

### Talablar
- **Operatsion tizim:** Windows 10 yoki Windows 11 (64-bit)
- **Python:** Python 3.12 yoki undan yuqori (`Add python.exe to PATH` belgilangan bo'lsin)
- **Uskuna:** Mikrofon (ovozli buyruqlar uchun) va ixtiyoriy veb-kamera (OpenCV/MediaPipe uchun)

### Qadam-baqadam o'rnatish
1. Terminal (PowerShell yoki CMD) ni `NOVA` papkasi ichida oching.
2. Virtual muhit yarating va faollashtiring:
   ```bat
   python -m venv .venv
   .venv\Scripts\activate
   ```
3. Barcha kutubxonalarni o'rnating:
   ```bat
   pip install -r requirements.txt
   ```
4. Sozlamalar faylini yarating:
   ```bat
   copy .env.example .env
   ```
   So'ng `.env` faylini ochib kerakli kalitlarni kiriting (yoki ilovani ishga tushirib **Sozlamalar** oynasida Windows Credential Manager orqali xavfsiz saqlang).
5. **(Tavsiya etiladi) Oflayn Wake-Word uchun Vosk modeli:**
   - [Vosk Models](https://alphacephei.com/vosk/models) sahifasidan o'zbek (`vosk-model-small-uz-0.22`) modelini yuklab oling.
   - Uni `NOVA/assets/models/vosk-model-small-uz-0.22/` papkasiga chiqaring.
   - Shunda `"N.O.V.A., uyg'on!"` iborasi **100% oflayn** ishlaydi va kutish rejimida hech qanday audio internetga yuborilmaydi.
6. Ilovani ishga tushiring:
   ```bat
   python main.py
   ```

---

## 2. Qaysi funksiyalar oflayn, qaysilari internet / API kalit talab qiladi?

| Funksiya | Internet kerakmi? | API kalit kerakmi? | Izoh |
| --- | --- | --- | --- |
| Wake-word (`N.O.V.A., uyg'on!`) va Kutish (`N.O.V.A., bo'shsan.`) | **Yo'q (Oflayn)** | Yo'q | Vosk modeli + mahalliy VAD orqali ishlaydi |
| Kompyuter nazorati (Notepad, Kalkulyator, Ovoz, Vaqt) | **Yo'q (Oflayn)** | Yo'q | Ruxsat etilgan ro'yxat (`config/allowlist.json`) asosida |
| Kamera, Yuz aniqlash, Qo'l jestlari (OpenCV + MediaPipe) | **Yo'q (Oflayn)** | Yo'q | Faqat kompyuterning o'zida qayta ishlanadi |
| Oflayn ovoz sintezi (`pyttsx3_offline`) | **Yo'q (Oflayn)** | Yo'q | Windows SAPI5 orqali |
| Tabiiy O'zbek TTS (`edge_tts` — Madina / Sardor) | Ha | Yo'q | Microsoft Edge neural ovozlari |
| AI Miya va Kamera AI tasviri (`AiBrain`) | Ha | **Ha (`GEMINI_API_KEY`)** | Google AI Studio kaliti kerak |
| Telegram avto-javob | Ha | **Ha (`TELEGRAM_BOT_TOKEN`)** | Rasmiy `@BotFather` bot tokeni |
| Instagram avto-javob | Ha | **Ha (`INSTAGRAM_ACCESS_TOKEN`)** | Rasmiy Meta Graph API (faqat Business/Creator) |

---

## 3. Telegram va Instagram rasmiy sozlash

### Telegram (Rasmiy Bot API)
- Telegram'da `@BotFather` ga kiring va `/newbot` buyrug'i bilan bot yarating.
- Olingan tokenni `TELEGRAM_BOT_TOKEN` ga kiriting.
- **Muhim:** Rasmiy Bot API faqat botingizga yozilgan xabarlarga yoki bot a'zo bo'lgan guruhlarga javob beradi. Shaxsiy akkaunt parollari so'ralmaydi.

### Instagram (Rasmiy Meta Graph API)
- Meta faqat Facebook Sahifaga (Page) ulangan **Instagram Professional (Business yoki Creator)** akkauntlar uchun rasmiy Messaging API taqdim etadi.
- Oddiy shaxsiy Instagram akkauntlar Meta tomonidan API orqali qo'llab-quvvatlanmaydi.
- Meta for Developers portalidan Page Access Token, `INSTAGRAM_PAGE_ID` va `INSTAGRAM_WEBHOOK_VERIFY_TOKEN` oling.

---

## 4. Windows `.exe` faylini yig'ish (PyInstaller)

Avtomatik yig'ish uchun shunchaki `build.bat` faylini ishga tushiring:
```bat
build.bat
```
Skript virtual muhit yaratadi, barcha kutubxonalarni o'rnatadi, `pytest` testlarini tekshiradi va tayyor dasturni quyidagi manzilda yaratadi:
`dist\NOVA_Darknes_Ultimate.exe`

---

## 5. Xavfsizlik kafolatlari
- Hech qanday AI yaratgan terminal buyruqlari (`cmd` / `powershell`) avtomatik bajarilmaydi.
- Faqat `config/allowlist.json` da ruxsat berilgan dastur va manzillar ochiladi.
- Fayl o'chirish, xabar yuborish, yuzni saqlash va Windows avto-ishga tushirish uchun **Darknes** dan alohida tasdiq so'raladi.
- API kalitlar manba kodida saqlanmaydi (`.env` yoki Windows Credential Manager).

---

## 6. Aqlli AI Miya, Doimiy Xotira va Nutqni Bo'lish (Barge-In)
- **Gemini Function Calling:** N.O.V.A. tabiiy o'zbek tilidagi murojaatdan niyatni tushunib, ruxsat etilgan vositalarni (`open_website`, `search_google`, `launch_app`, `adjust_volume`, `get_current_time`) xavfsiz tanlaydi va faqat haqiqiy bajarilgan natijaga tayanib javob beradi.
- **Doimiy Xotira (`Xotira` oynasi / `config/memory.json`):** Foydalanuvchi tasdiqlagan afzalliklar, loyiha tafsilotlari, eslatmalar va suhbat tarixi saqlanadi. Egasi **Xotira** bo'limidan barcha yozuvlarni ko'rishi, tahrirlashi va o'chirishi mumkin.
- **Ovozni bo'lish (Barge-In):** N.O.V.A. gapirayotganda foydalanuvchi gapira boshlasa yoki to'xtatish tugmasini bossa, nutq darhol to'xtatiladi va yangi savol tinglanadi.

