import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.wake_word import WakeWordDetector, normalize_uzbek_phrase


class WakeWordTests(unittest.TestCase):
    def setUp(self) -> None:
        self.detector = WakeWordDetector()

    def test_normalization(self) -> None:
        self.assertEqual(normalize_uzbek_phrase("N.O.V.A., uyg'on!"), "n o v a uygon")
        self.assertEqual(normalize_uzbek_phrase("Nova, bo‘shsan."), "nova boshsan")

    def test_wake_word_matches(self) -> None:
        self.assertTrue(self.detector.matches_wake_word("N.O.V.A., uyg'on!"))
        self.assertTrue(self.detector.matches_wake_word("nova uygon"))
        self.assertFalse(self.detector.matches_wake_word("bugun ob havo qanday"))

    def test_sleep_phrase_matches(self) -> None:
        self.assertTrue(self.detector.matches_sleep_phrase("N.O.V.A., bo'shsan."))
        self.assertTrue(self.detector.matches_sleep_phrase("nova boshsan"))
        self.assertFalse(self.detector.matches_sleep_phrase("youtubeni och"))


if __name__ == "__main__":
    unittest.main()
