import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.command_router import CommandRouter


class FakeComputerControl:
    def __init__(self) -> None:
        self.launched: list[str] = []
        self.volume_deltas: list[float] = []

    def launch_allowed_app(self, app_key: str) -> tuple[bool, str]:
        self.launched.append(app_key)
        return True, f"{app_key} ochildi."

    def adjust_volume(self, delta: float) -> tuple[bool, str]:
        self.volume_deltas.append(delta)
        return True, "Ovoz sozlandi."

    def set_mute(self, muted: bool) -> tuple[bool, str]:
        return True, "Ovoz o'chirildi." if muted else "Ovoz yoqildi."

    def get_time_uzbek(self) -> str:
        return "Hozir soat 12:00."


class FakeBrowserControl:
    def __init__(self) -> None:
        self.opened: list[str] = []
        self.searched: list[str] = []

    def open_allowed_url(self, site_key: str) -> tuple[bool, str]:
        self.opened.append(site_key)
        return True, f"{site_key} ochildi."

    def search_google(self, query: str) -> tuple[bool, str]:
        self.searched.append(query)
        return True, f"Qidirildi: {query}"


class CommandRouterTests(unittest.TestCase):
    def setUp(self) -> None:
        self.comp = FakeComputerControl()
        self.browser = FakeBrowserControl()
        self.router = CommandRouter(
            computer_control=self.comp,
            browser_control=self.browser,
            owner_name="Darknes",
            confirm_callback=lambda _msg: False,
        )

    def test_uzbek_commands(self) -> None:
        res_yt = self.router.route("YouTube'ni och.")
        self.assertTrue(res_yt.handled)
        self.assertEqual(self.browser.opened[-1], "youtube")

        res_tg = self.router.route("Telegram'ni och.")
        self.assertTrue(res_tg.handled)
        self.assertEqual(self.comp.launched[-1], "telegram")

        res_ig = self.router.route("Instagram'ni och.")
        self.assertTrue(res_ig.handled)
        self.assertEqual(self.browser.opened[-1], "instagram")

        res_gg = self.router.route("Google'ni och.")
        self.assertTrue(res_gg.handled)
        self.assertEqual(self.browser.opened[-1], "google")

        res_search = self.router.route("Google'dan game deb qidir.")
        self.assertTrue(res_search.handled)
        self.assertEqual(self.browser.searched[-1], "game")

        res_np = self.router.route("Notepad'ni och.")
        self.assertTrue(res_np.handled)
        self.assertEqual(self.comp.launched[-1], "notepad")

        res_calc = self.router.route("Kalkulyatorni och.")
        self.assertTrue(res_calc.handled)
        self.assertEqual(self.comp.launched[-1], "calculator")

        res_vol = self.router.route("Kompyuter ovozini pasaytir.")
        self.assertTrue(res_vol.handled)
        self.assertLess(self.comp.volume_deltas[-1], 0)

        res_time = self.router.route("Vaqtni ayt.")
        self.assertTrue(res_time.handled)
        self.assertIn("12:00", res_time.response_text)

        res_help = self.router.route("N.O.V.A., yordam ber.")
        self.assertTrue(res_help.handled)
        self.assertIn("Darknes", res_help.response_text)

    def test_blocks_arbitrary_shell_injection(self) -> None:
        res = self.router.route("powershell Remove-Item -Recurse")
        self.assertTrue(res.handled)
        self.assertFalse(res.success)
        self.assertEqual(res.action, "blocked_unsafe_command")

    def test_delete_requires_confirmation(self) -> None:
        res = self.router.route("faylni o'chir")
        self.assertTrue(res.handled)
        self.assertTrue(res.requires_confirmation)
        self.assertFalse(res.success)

    def test_ishga_tushir_and_execute_tool(self) -> None:
        res_calc = self.router.route("Kalkulyatorni ishga tushir.")
        self.assertTrue(res_calc.handled)
        self.assertEqual(self.comp.launched[-1], "calculator")

        res_tool = self.router.execute_tool("search_google", {"query": "Minecraft"})
        self.assertTrue(res_tool.success)
        self.assertEqual(self.browser.searched[-1], "Minecraft")

        res_bad = self.router.execute_tool("run_arbitrary_shell", {"cmd": "dir"})
        self.assertFalse(res_bad.success)
        self.assertEqual(res_bad.action, "unknown_tool")


if __name__ == "__main__":
    unittest.main()
