import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.memory_store import MemoryStore


class MemoryStoreTests(unittest.TestCase):
    def test_crud_memories_and_conversation_history(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            mem_path = Path(tmp) / "memory.json"
            store = MemoryStore(path=mem_path, owner_name="Darknes")

            item = store.add_memory("N.O.V.A. loyihasi PySide6 da yozilgan", category="project")
            self.assertIsNotNone(item)
            assert item is not None
            self.assertEqual(len(store.list_memories()), 1)

            updated = store.update_memory(
                item.id, "N.O.V.A. loyihasi PySide6 va Gemini API da yozilgan", category="project"
            )
            self.assertTrue(updated)

            store.append_turn("user", "Salom N.O.V.A.")
            store.append_turn("model", "Assalomu alaykum, Darknes!")

            reloaded = MemoryStore(path=mem_path, owner_name="Darknes")
            self.assertEqual(len(reloaded.list_memories()), 1)
            self.assertIn("Gemini API", reloaded.list_memories()[0].content)
            self.assertEqual(len(reloaded.conversation_history), 2)

            self.assertTrue(reloaded.delete_memory(item.id))
            self.assertEqual(len(reloaded.list_memories()), 0)

            reloaded.clear_history()
            self.assertEqual(len(reloaded.conversation_history), 0)

    def test_frozen_path_seeding_and_asset_resolution(self) -> None:
        import config.settings as cfg_mod

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            bundle = root / "bundle"
            data = root / "appdata"
            (bundle / "config").mkdir(parents=True)
            (bundle / "assets").mkdir(parents=True)
            (bundle / "config" / "memory.json").write_text(
                '{"owner_name": "Darknes", "memories": [], "conversation_history": []}',
                encoding="utf-8",
            )
            (bundle / "config" / "preferences.json").write_text("{}", encoding="utf-8")
            (bundle / "assets" / "nova_icon.svg").write_text("<svg/>", encoding="utf-8")

            orig_bundle, orig_data = cfg_mod.BUNDLE_DIR, cfg_mod.DATA_DIR
            orig_cfg, orig_bcfg = cfg_mod.CONFIG_DIR, cfg_mod.BUNDLED_CONFIG_DIR
            try:
                cfg_mod.BUNDLE_DIR = bundle
                cfg_mod.DATA_DIR = data
                cfg_mod.CONFIG_DIR = data / "config"
                cfg_mod.BUNDLED_CONFIG_DIR = bundle / "config"
                cfg_mod.ensure_writable_config_seeded()
                self.assertTrue((data / "config" / "memory.json").exists())
                self.assertEqual(
                    cfg_mod.resolve_asset_path("assets/nova_icon.svg"),
                    bundle / "assets" / "nova_icon.svg",
                )
                (data / "assets").mkdir(parents=True)
                (data / "assets" / "nova_icon.svg").write_text("<svg>custom</svg>", encoding="utf-8")
                self.assertEqual(
                    cfg_mod.resolve_asset_path("assets/nova_icon.svg"),
                    data / "assets" / "nova_icon.svg",
                )
            finally:
                cfg_mod.BUNDLE_DIR, cfg_mod.DATA_DIR = orig_bundle, orig_data
                cfg_mod.CONFIG_DIR, cfg_mod.BUNDLED_CONFIG_DIR = orig_cfg, orig_bcfg


if __name__ == "__main__":
    unittest.main()
