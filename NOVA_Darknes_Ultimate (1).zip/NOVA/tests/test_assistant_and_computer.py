import sys
import unittest
from pathlib import Path
from unittest.mock import MagicMock

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config.settings import NovaConfig
from core.assistant import AssistantState, NovaAssistant
from core.command_router import CommandRouter
from core.wake_word import WakeWordDetector
from modules.browser_control import BrowserControl
from modules.computer_control import ComputerControl


class AssistantAndComputerTests(unittest.TestCase):
    def _build_assistant(self) -> NovaAssistant:
        cfg = NovaConfig()
        wake = WakeWordDetector()
        voice_in = MagicMock()
        voice_out = MagicMock()
        ai_brain = MagicMock()
        ai_brain.ask.return_value = MagicMock(text="AI javobi")
        comp = ComputerControl()
        browser = BrowserControl()
        router = CommandRouter(comp, browser, owner_name="Darknes")
        return NovaAssistant(cfg, wake, voice_in, voice_out, ai_brain, router)

    def test_sleep_ignores_normal_commands_until_wake(self) -> None:
        assistant = self._build_assistant()
        self.assertEqual(assistant.state, AssistantState.SLEEP)

        # Normal command ignored while sleeping
        res = assistant.handle_user_utterance("Vaqtni ayt.")
        self.assertEqual(res, "")
        self.assertEqual(assistant.state, AssistantState.SLEEP)

        # Wake word activates assistant
        greet = assistant.handle_user_utterance("N.O.V.A., uyg'on!")
        self.assertEqual(greet, "Assalomu alaykum, Darknes. Sizni eshitaman.")
        self.assertEqual(assistant.state, AssistantState.ACTIVE)

        # Now normal command works
        time_res = assistant.handle_user_utterance("Vaqtni ayt.")
        self.assertIn("Hozir soat", time_res)

        # Sleep command returns to SLEEP
        bye = assistant.handle_user_utterance("N.O.V.A., bo'shsan.")
        self.assertEqual(bye, "Xo'p, Darknes. Kutish rejimiga o'tdim.")
        self.assertEqual(assistant.state, AssistantState.SLEEP)

    def test_computer_control_blocks_unlisted_app_and_unconfirmed_autostart(self) -> None:
        comp = ComputerControl()
        ok, _ = comp.launch_allowed_app("cmd_shell")
        self.assertFalse(ok)

        ok_auto, _ = comp.set_windows_autostart(True, owner_confirmed=False)
        self.assertFalse(ok_auto)


if __name__ == "__main__":
    unittest.main()
