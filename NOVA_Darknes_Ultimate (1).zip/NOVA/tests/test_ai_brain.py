import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config.settings import NovaConfig
from core import ai_brain as ai_brain_module
from core.ai_brain import AiBrain


class _FakeTypes:
    class Type:
        OBJECT = "OBJECT"
        STRING = "STRING"

    class Schema:
        def __init__(self, **kwargs):
            self.kwargs = kwargs

    class FunctionDeclaration:
        def __init__(self, **kwargs):
            self.kwargs = kwargs

    class Tool:
        def __init__(self, **kwargs):
            self.kwargs = kwargs

    class GenerateContentConfig:
        def __init__(self, **kwargs):
            self.kwargs = kwargs

    class Content:
        def __init__(self, role, parts):
            self.role = role
            self.parts = parts

    class Part:
        @staticmethod
        def from_text(text):
            return {"text": text}

        @staticmethod
        def from_bytes(data, mime_type):
            return {"data": data, "mime_type": mime_type}

        @staticmethod
        def from_function_response(name, response):
            return {"function_response": {"name": name, "response": response}}


class AiBrainTests(unittest.TestCase):
    def test_missing_key_reports_honestly(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            cfg = NovaConfig()
            cfg.get_gemini_api_key = lambda: ""  # type: ignore[method-assign]
            brain = AiBrain(
                cfg,
                preferences_path=Path(tmp) / "prefs.json",
                memory_path=Path(tmp) / "memory.json",
            )
            reply = brain.ask("Salom")
            self.assertEqual(reply.error, "MISSING_API_KEY")
            self.assertIn("GEMINI_API_KEY", reply.text)

    def test_preference_persists_only_on_approval(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            pref_file = Path(tmp) / "prefs.json"
            mem_file = Path(tmp) / "memory.json"
            cfg = NovaConfig()
            brain = AiBrain(cfg, preferences_path=pref_file, memory_path=mem_file)
            self.assertEqual(brain.approved_preferences, [])
            ok = brain.approve_and_save_preference(
                "Darknes Python dasturlashni yoqtiradi", category="preference"
            )
            self.assertTrue(ok)
            reloaded = AiBrain(cfg, preferences_path=pref_file, memory_path=mem_file)
            self.assertIn("Darknes Python dasturlashni yoqtiradi", reloaded.approved_preferences)

    def test_function_calling_executes_tool_and_grounds_reply(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            cfg = NovaConfig()
            cfg.get_gemini_api_key = lambda: "test-key"  # type: ignore[method-assign]

            calls_seen = []

            class FakeModels:
                def __init__(self) -> None:
                    self.step = 0

                def generate_content(self, **_kwargs):
                    self.step += 1
                    if self.step == 1:
                        return SimpleNamespace(
                            function_calls=[
                                SimpleNamespace(
                                    id="call-1",
                                    name="launch_app",
                                    args={"app_key": "calculator"},
                                )
                            ],
                            candidates=[SimpleNamespace(content={"role": "model", "parts": []})],
                            text="",
                        )
                    return SimpleNamespace(
                        function_calls=[],
                        candidates=[],
                        text="Kalkulyator muvaffaqiyatli ishga tushirildi, Darknes.",
                    )

            fake_client = SimpleNamespace(models=FakeModels())

            def fake_executor(name, args):
                calls_seen.append((name, args))
                return True, "open_calculator", "Kalkulyator ochildi."

            orig_types = ai_brain_module.types
            ai_brain_module.types = _FakeTypes  # type: ignore[assignment]
            try:
                brain = AiBrain(
                    cfg,
                    preferences_path=Path(tmp) / "prefs.json",
                    memory_path=Path(tmp) / "memory.json",
                    tool_executor=fake_executor,
                )
                brain._client = fake_client
                reply = brain.ask("Menga hisoblagichni ochib ber")
            finally:
                ai_brain_module.types = orig_types

            self.assertEqual(calls_seen, [("launch_app", {"app_key": "calculator"})])
            self.assertEqual(len(reply.executed_tools), 1)
            self.assertTrue(reply.executed_tools[0]["success"])
            self.assertIn("Kalkulyator", reply.text)

    def test_api_error_is_never_masked_with_fake_reply(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            cfg = NovaConfig()
            cfg.get_gemini_api_key = lambda: "test-key"  # type: ignore[method-assign]

            class FailingModels:
                def generate_content(self, **_kwargs):
                    raise RuntimeError("Network timeout")

            orig_types = ai_brain_module.types
            ai_brain_module.types = _FakeTypes  # type: ignore[assignment]
            try:
                brain = AiBrain(
                    cfg,
                    preferences_path=Path(tmp) / "prefs.json",
                    memory_path=Path(tmp) / "memory.json",
                )
                brain._client = SimpleNamespace(models=FailingModels())
                reply = brain.ask("Kvant kompyuter nima?")
            finally:
                ai_brain_module.types = orig_types

            self.assertEqual(reply.error, "Network timeout")
            self.assertIn("xatolik", reply.text.lower())


if __name__ == "__main__":
    unittest.main()
