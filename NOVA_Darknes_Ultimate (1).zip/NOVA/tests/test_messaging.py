import sys
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from modules.instagram import InstagramOfficialClient
from modules.telegram import TelegramBotClient


class MessagingTests(unittest.TestCase):
    def test_telegram_auto_reply_respects_toggle(self) -> None:
        tg = TelegramBotClient(bot_token="123:test", auto_reply_enabled=False)
        update = {
            "update_id": 1,
            "message": {
                "chat": {"id": 999},
                "from": {"first_name": "Ali", "is_bot": False},
                "text": "Salom Darknes",
            },
        }
        self.assertFalse(tg.process_update(update))

        tg.auto_reply_enabled = True
        with patch.object(tg, "_post_message", return_value=(True, "ok")) as mock_post:
            sent = tg.process_update(update)
            self.assertTrue(sent)
            mock_post.assert_called_once_with(
                999, "Darknes online emas. Bir oz kuting! Javob berdi: N.O.V.A."
            )

    def test_instagram_webhook_respects_toggle(self) -> None:
        ig = InstagramOfficialClient(
            access_token="tok",
            page_id="12345",
            auto_reply_enabled=True,
        )
        payload = {
            "entry": [
                {
                    "messaging": [
                        {
                            "sender": {"id": "ig_user_1"},
                            "message": {"text": "Qachon onlayn bo'lasiz?"},
                        }
                    ]
                }
            ]
        }
        with patch.object(ig, "_post_reply", return_value=(True, "ok")) as mock_reply:
            count = ig.handle_webhook_payload(payload)
            self.assertEqual(count, 1)
            mock_reply.assert_called_once_with(
                "ig_user_1", "Darknes online emas. Bir oz kuting! Javob berdi: N.O.V.A."
            )

    def test_manual_send_requires_owner_confirmation(self) -> None:
        tg = TelegramBotClient(bot_token="123:test")
        ok, _ = tg.send_message(999, "Salom", owner_confirmed=False)
        self.assertFalse(ok)


if __name__ == "__main__":
    unittest.main()
