"""Safe browser control module with allowlisted domains and encoded search queries."""

from __future__ import annotations

import webbrowser
from typing import Any
from urllib.parse import quote_plus

from config.settings import load_allowlist


class BrowserControl:
    """Opens only allowlisted websites and properly URL-encoded Google searches."""

    def __init__(self, allowlist: dict[str, Any] | None = None) -> None:
        self.allowlist = allowlist or load_allowlist()

    def open_allowed_url(self, site_key: str) -> tuple[bool, str]:
        urls = self.allowlist.get("allowed_urls", {})
        url = urls.get(site_key)
        if not url:
            return False, f"'{site_key}' manzili ruxsat etilgan ro'yxatda yo'q."

        if not url.startswith("https://"):
            return False, "Faqat HTTPS manzillariga ruxsat beriladi."

        webbrowser.open(url, new=2)
        return True, f"{site_key.capitalize()} ochildi."

    def search_google(self, query: str) -> tuple[bool, str]:
        cleaned = query.strip()
        if not cleaned:
            return False, "Qidiruv so'rovi bo'sh."

        encoded = quote_plus(cleaned)
        search_url = f"https://www.google.com/search?q={encoded}"
        webbrowser.open(search_url, new=2)
        return True, f"Google'dan '{cleaned}' bo'yicha qidiruv ochildi."
