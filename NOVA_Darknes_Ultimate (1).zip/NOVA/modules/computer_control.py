"""Safe Windows computer control module with explicit application allowlisting."""

from __future__ import annotations

import logging
import os
import platform
import socket
import subprocess
import sys
import webbrowser
from datetime import datetime
from pathlib import Path
from typing import Any

from config.settings import load_allowlist

logger = logging.getLogger("nova.computer_control")

try:
    import psutil
except Exception:  # pragma: no cover
    psutil = None

if platform.system() == "Windows":
    try:
        import winreg
    except Exception:  # pragma: no cover
        winreg = None
else:
    winreg = None

UZBEK_MONTHS = (
    "",
    "yanvar",
    "fevral",
    "mart",
    "aprel",
    "may",
    "iyun",
    "iyul",
    "avgust",
    "sentabr",
    "oktabr",
    "noyabr",
    "dekabr",
)

UZBEK_WEEKDAYS = (
    "dushanba",
    "seshanba",
    "chorshanba",
    "payshanba",
    "juma",
    "shanba",
    "yakshanba",
)


class ComputerControl:
    """Executes only validated, allowlisted Windows computer tasks."""

    REGISTRY_RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
    APP_REGISTRY_NAME = "NOVA_Darknes_Ultimate"

    def __init__(self, allowlist: dict[str, Any] | None = None) -> None:
        self.allowlist = allowlist or load_allowlist()

    def launch_allowed_app(self, app_key: str) -> tuple[bool, str]:
        """Launches an explicitly allowlisted Windows app without shell=True."""
        apps = self.allowlist.get("allowed_apps", {})
        spec = apps.get(app_key)
        if not spec:
            return False, f"'{app_key}' dasturi ruxsat etilgan ro'yxatda yo'q."

        display_name = spec.get("display_name", app_key)
        if platform.system() != "Windows":
            fallback_url = spec.get("fallback_url")
            if fallback_url:
                webbrowser.open(fallback_url)
                return True, f"{display_name} brauzer orqali ochildi."
            return (
                False,
                f"{display_name} faqat Windows 10/11 tizimida mahalliy dastur sifatida ochiladi.",
            )

        for raw_exe in spec.get("executables", []):
            expanded = os.path.expandvars(raw_exe)
            exe_path = Path(expanded)
            try:
                if exe_path.is_absolute() and not exe_path.exists():
                    continue
                subprocess.Popen([str(exe_path)], shell=False)
                return True, f"{display_name} ochildi."
            except FileNotFoundError:
                continue
            except Exception as exc:
                logger.warning("Failed launching %s: %s", expanded, exc)

        fallback_url = spec.get("fallback_url")
        if fallback_url:
            webbrowser.open(fallback_url)
            return True, f"{display_name} brauzerda ochildi."

        return False, f"{display_name} kompyuterda topilmadi."

    def adjust_volume(self, delta: float) -> tuple[bool, str]:
        """Adjusts Windows master speaker volume safely using pycaw."""
        if platform.system() != "Windows":
            return False, "Tizim ovozini boshqarish faqat Windows 10/11 da ishlaydi."

        try:
            from ctypes import POINTER, cast
            from comtypes import CLSCTX_ALL
            from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume

            devices = AudioUtilities.GetSpeakers()
            interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
            volume = cast(interface, POINTER(IAudioEndpointVolume))
            current = float(volume.GetMasterVolumeLevelScalar())
            target = max(0.0, min(1.0, current + delta))
            volume.SetMasterVolumeLevelScalar(target, None)
            percent = int(round(target * 100))
            direction = "pasaytirildi" if delta < 0 else "oshirildi"
            return True, f"Kompyuter ovozi {percent}% ga {direction}."
        except Exception as exc:
            logger.warning("Volume adjust failed: %s", exc)
            return False, f"Ovozni o'zgartirib bo'lmadi: {exc}"

    def set_mute(self, muted: bool) -> tuple[bool, str]:
        if platform.system() != "Windows":
            return False, "Ovozni o'chirish faqat Windows 10/11 da ishlaydi."
        try:
            from ctypes import POINTER, cast
            from comtypes import CLSCTX_ALL
            from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume

            devices = AudioUtilities.GetSpeakers()
            interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
            volume = cast(interface, POINTER(IAudioEndpointVolume))
            volume.SetMute(1 if muted else 0, None)
            return True, "Kompyuter ovozi o'chirildi." if muted else "Kompyuter ovozi yoqildi."
        except Exception as exc:
            return False, f"Ovoz holatini o'zgartirib bo'lmadi: {exc}"

    def get_time_uzbek(self) -> str:
        now = datetime.now()
        weekday = UZBEK_WEEKDAYS[now.weekday()]
        month = UZBEK_MONTHS[now.month]
        return f"Hozir soat {now:%H:%M}, bugun {now.day}-{month}, {weekday}."

    def get_system_telemetry(self) -> dict[str, Any]:
        """Returns real CPU, RAM, and connectivity telemetry."""
        cpu_percent = 0.0
        ram_percent = 0.0
        ram_used_gb = 0.0
        ram_total_gb = 0.0

        if psutil is not None:
            try:
                cpu_percent = float(psutil.cpu_percent(interval=None))
                mem = psutil.virtual_memory()
                ram_percent = float(mem.percent)
                ram_used_gb = round(mem.used / (1024**3), 2)
                ram_total_gb = round(mem.total / (1024**3), 2)
            except Exception:
                pass

        return {
            "cpu_percent": cpu_percent,
            "ram_percent": ram_percent,
            "ram_used_gb": ram_used_gb,
            "ram_total_gb": ram_total_gb,
            "internet_connected": self.check_internet(),
        }

    @staticmethod
    def check_internet(timeout: float = 1.5) -> bool:
        try:
            with socket.create_connection(("8.8.8.8", 53), timeout=timeout):
                return True
        except OSError:
            return False

    def set_windows_autostart(self, enabled: bool, owner_confirmed: bool) -> tuple[bool, str]:
        """Configures Windows startup ONLY when owner explicitly confirms."""
        if not owner_confirmed:
            return False, "Windows avto-ishga tushirish uchun egasining tasdig'i talab qilinadi."
        if platform.system() != "Windows" or winreg is None:
            return False, "Windows avto-ishga tushirish faqat Windows 10/11 da mavjud."

        try:
            with winreg.OpenKey(
                winreg.HKEY_CURRENT_USER, self.REGISTRY_RUN_KEY, 0, winreg.KEY_SET_VALUE
            ) as key:
                if enabled:
                    target = (
                        f'"{sys.executable}"'
                        if getattr(sys, "frozen", False)
                        else f'"{sys.executable}" "{Path(__file__).resolve().parent.parent / "main.py"}"'
                    )
                    winreg.SetValueEx(key, self.APP_REGISTRY_NAME, 0, winreg.REG_SZ, target)
                    return True, "N.O.V.A. Windows ishga tushganda avtomatik ochiladigan qilindi."
                try:
                    winreg.DeleteValue(key, self.APP_REGISTRY_NAME)
                except FileNotFoundError:
                    pass
                return True, "Windows avto-ishga tushirish o'chirildi."
        except Exception as exc:
            return False, f"Avto-ishga tushirish sozlamasida xatolik: {exc}"
