"""OpenCV + MediaPipe camera module with explicit user control and consent-gated face enrollment."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

try:
    import numpy as np
except Exception:  # pragma: no cover
    np = None

from config.settings import DATA_DIR
from modules.hand_tracking import HandGestureTracker

logger = logging.getLogger("nova.camera")

try:
    import cv2
except Exception:  # pragma: no cover
    cv2 = None

try:
    import mediapipe as mp
except Exception:  # pragma: no cover
    mp = None


@dataclass
class VisionAnalysis:
    frame_rgb: np.ndarray | None = None
    faces_count: int = 0
    recognized_owner: bool = False
    hand_gestures: list[str] = field(default_factory=list)
    camera_active: bool = False
    error: str | None = None


class CameraManager:
    """Manages local webcam capture cleanly. Never records or transmits secretly."""

    ENROLLED_FACE_PATH = DATA_DIR / "assets" / "enrolled_faces" / "owner_face_hist.npy"

    def __init__(self, camera_index: int = 0, face_recognition_consent: bool = False) -> None:
        self.camera_index = camera_index
        self.face_recognition_consent = face_recognition_consent
        self.is_active = False
        self._capture: Any = None
        self._face_detector = None
        self._hand_tracker = HandGestureTracker()
        self._owner_hist: np.ndarray | None = None

        if mp is not None:
            try:
                self._face_detector = mp.solutions.face_detection.FaceDetection(
                    model_selection=0, min_detection_confidence=0.6
                )
            except Exception as exc:
                logger.warning("MediaPipe FaceDetection init failed: %s", exc)

        self._load_enrolled_face()

    def _load_enrolled_face(self) -> None:
        if self.face_recognition_consent and self.ENROLLED_FACE_PATH.exists():
            try:
                self._owner_hist = np.load(self.ENROLLED_FACE_PATH)
            except Exception:
                self._owner_hist = None

    def start(self) -> tuple[bool, str]:
        if self.is_active:
            return True, "Kamera allaqachon yoqilgan."
        if cv2 is None:
            return False, "OpenCV kutubxonasi topilmadi."

        cap = cv2.VideoCapture(self.camera_index)
        if not cap or not cap.isOpened():
            if cap:
                cap.release()
            return False, "Kameraga ulanib bo'lmadi."

        self._capture = cap
        self.is_active = True
        return True, "Kamera yoqildi."

    def stop(self) -> None:
        self.is_active = False
        if self._capture is not None:
            try:
                self._capture.release()
            except Exception:
                pass
            self._capture = None

    def enroll_owner_face(self, consent_confirmed: bool) -> tuple[bool, str]:
        """Saves a local facial histogram template ONLY with explicit owner consent."""
        if not consent_confirmed:
            return False, "Yuzni ro'yxatdan o'tkazish uchun egasining roziligi kerak."
        if not self.is_active or self._capture is None or cv2 is None:
            return False, "Avval kamerani yoqing."

        ok, frame = self._capture.read()
        if not ok or frame is None:
            return False, "Kadr olinmadi."

        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        bbox = self._detect_primary_face_bbox(rgb)
        if bbox is None:
            return False, "Kadrda yuz aniqlanmadi. Kameraga to'g'ri qarang."

        x1, y1, x2, y2 = bbox
        crop = cv2.cvtColor(rgb[y1:y2, x1:x2], cv2.COLOR_RGB2GRAY)
        hist = self._compute_face_hist(crop)

        self.ENROLLED_FACE_PATH.parent.mkdir(parents=True, exist_ok=True)
        np.save(self.ENROLLED_FACE_PATH, hist)
        self._owner_hist = hist
        self.face_recognition_consent = True
        return True, "Darknes yuzi mahalliy xotirada xavfsiz saqlandi."

    def read_and_process(self, detect_hands: bool = True) -> VisionAnalysis:
        """Captures one frame, runs local MediaPipe face/hand detection, returns annotated RGB."""
        if not self.is_active or self._capture is None or cv2 is None:
            return VisionAnalysis(camera_active=False)

        ok, frame_bgr = self._capture.read()
        if not ok or frame_bgr is None:
            return VisionAnalysis(camera_active=True, error="Kadr o'qib bo'lmadi.")

        frame_bgr = cv2.flip(frame_bgr, 1)
        frame_rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        h, w, _ = frame_rgb.shape

        faces_count = 0
        recognized_owner = False

        if self._face_detector is not None:
            res = self._face_detector.process(frame_rgb)
            if res and res.detections:
                faces_count = len(res.detections)
                for det in res.detections:
                    box = det.location_data.relative_bounding_box
                    x1 = max(0, int(box.xmin * w))
                    y1 = max(0, int(box.ymin * h))
                    x2 = min(w, int((box.xmin + box.width) * w))
                    y2 = min(h, int((box.ymin + box.height) * h))

                    label = "Yuz aniqlandi"
                    if (
                        self.face_recognition_consent
                        and self._owner_hist is not None
                        and x2 > x1
                        and y2 > y1
                    ):
                        crop_gray = cv2.cvtColor(frame_rgb[y1:y2, x1:x2], cv2.COLOR_RGB2GRAY)
                        hist = self._compute_face_hist(crop_gray)
                        score = float(cv2.compareHist(self._owner_hist, hist, cv2.HISTCMP_CORREL))
                        if score >= 0.72:
                            recognized_owner = True
                            label = f"Darknes ({score:.0%})"

                    cv2.rectangle(frame_rgb, (x1, y1), (x2, y2), (6, 182, 212), 2)
                    cv2.putText(
                        frame_rgb,
                        label,
                        (x1, max(20, y1 - 8)),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.55,
                        (6, 182, 212),
                        2,
                    )

        gestures: list[str] = []
        if detect_hands:
            frame_rgb, gestures = self._hand_tracker.process_frame(frame_rgb)

        return VisionAnalysis(
            frame_rgb=frame_rgb,
            faces_count=faces_count,
            recognized_owner=recognized_owner,
            hand_gestures=gestures,
            camera_active=True,
        )

    def capture_jpeg_snapshot(self) -> bytes | None:
        """Captures a single JPEG frame ONLY when owner requests AI Vision analysis."""
        if not self.is_active or self._capture is None or cv2 is None:
            return None
        ok, frame_bgr = self._capture.read()
        if not ok or frame_bgr is None:
            return None
        success, encoded = cv2.imencode(".jpg", frame_bgr)
        return bytes(encoded) if success else None

    def _detect_primary_face_bbox(self, frame_rgb: np.ndarray) -> tuple[int, int, int, int] | None:
        if self._face_detector is None:
            return None
        res = self._face_detector.process(frame_rgb)
        if not res or not res.detections:
            return None
        h, w, _ = frame_rgb.shape
        box = res.detections[0].location_data.relative_bounding_box
        x1 = max(0, int(box.xmin * w))
        y1 = max(0, int(box.ymin * h))
        x2 = min(w, int((box.xmin + box.width) * w))
        y2 = min(h, int((box.ymin + box.height) * h))
        if x2 <= x1 or y2 <= y1:
            return None
        return (x1, y1, x2, y2)

    @staticmethod
    def _compute_face_hist(gray_crop: np.ndarray) -> np.ndarray:
        resized = cv2.resize(gray_crop, (96, 96))
        hist = cv2.calcHist([resized], [0], None, [64], [0, 256])
        cv2.normalize(hist, hist)
        return hist.astype(np.float32)
