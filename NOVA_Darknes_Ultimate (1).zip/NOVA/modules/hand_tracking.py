"""MediaPipe hand landmark detection and deterministic gesture classifier."""

from __future__ import annotations

import logging
from typing import Any

try:
    import numpy as np
except Exception:  # pragma: no cover
    np = None

logger = logging.getLogger("nova.hand_tracking")

try:
    import cv2
except Exception:  # pragma: no cover
    cv2 = None

try:
    import mediapipe as mp
except Exception:  # pragma: no cover
    mp = None


class HandGestureTracker:
    """Detects hand landmarks and classifies gestures using MediaPipe Hands."""

    def __init__(self, max_num_hands: int = 2) -> None:
        self._hands: Any = None
        self._drawing = None
        if mp is not None:
            try:
                self._hands = mp.solutions.hands.Hands(
                    static_image_mode=False,
                    max_num_hands=max_num_hands,
                    min_detection_confidence=0.6,
                    min_tracking_confidence=0.5,
                )
                self._drawing = mp.solutions.drawing_utils
            except Exception as exc:
                logger.warning("MediaPipe Hands init failed: %s", exc)

    def process_frame(self, frame_rgb: np.ndarray) -> tuple[np.ndarray, list[str]]:
        if self._hands is None:
            return frame_rgb, []

        results = self._hands.process(frame_rgb)
        gestures: list[str] = []
        if results and results.multi_hand_landmarks:
            for hand_landmarks in results.multi_hand_landmarks:
                if self._drawing is not None and mp is not None:
                    self._drawing.draw_landmarks(
                        frame_rgb,
                        hand_landmarks,
                        mp.solutions.hands.HAND_CONNECTIONS,
                    )
                gesture = self.classify_landmarks(hand_landmarks.landmark)
                gestures.append(gesture)
                if cv2 is not None:
                    h, w, _ = frame_rgb.shape
                    wrist = hand_landmarks.landmark[0]
                    cv2.putText(
                        frame_rgb,
                        gesture,
                        (max(10, int(wrist.x * w) - 30), max(24, int(wrist.y * h) + 24)),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.55,
                        (59, 130, 246),
                        2,
                    )
        return frame_rgb, gestures

    @staticmethod
    def classify_landmarks(landmarks: Any) -> str:
        """Classifies hand pose into OPEN_PALM, FIST, VICTORY, THUMBS_UP, POINTING, or HAND."""
        # Tip IDs: thumb=4, index=8, middle=12, ring=16, pinky=20
        index_up = landmarks[8].y < landmarks[6].y
        middle_up = landmarks[12].y < landmarks[10].y
        ring_up = landmarks[16].y < landmarks[14].y
        pinky_up = landmarks[20].y < landmarks[18].y
        thumb_up = landmarks[4].y < landmarks[3].y and landmarks[4].y < landmarks[5].y

        up_count = sum((index_up, middle_up, ring_up, pinky_up))
        if up_count == 4:
            return "OPEN_PALM"
        if up_count == 0 and not thumb_up:
            return "FIST"
        if up_count == 0 and thumb_up:
            return "THUMBS_UP"
        if index_up and middle_up and not ring_up and not pinky_up:
            return "VICTORY"
        if index_up and not middle_up and not ring_up and not pinky_up:
            return "POINTING"
        return "HAND"
