"""Official Telegram Bot API integration for N.O.V.A.

Uses ONLY the official Telegram Bot API (https://api.telegram.org/bot<TOKEN>/...).
Never collects Telegram account passwords or bypasses platform restrictions.
Note: Bot API handles messages sent to your official @BotFather bot or groups where
the bot is an authorized member—not unauthorized personal DM scraping.
"""

from __future__ import annotations

import logging
import threading
import time
from typing import Any, Callable

try:
    import httpx
except Exception:  # pragma: no cover
    httpx = None

logger = logging.getLogger("nova.telegram")

DEFAULT_AUTO_REPLY = "Darknes online emas. Bir oz kuting! Javob berdi: N.O.V.A."


class TelegramBotClient:
    """Official Telegram Bot API polling & auto-reply manager."""

    API_BASE = "https://api.telegram.org"

    def __init__(
        self,
        bot_token: str = "",
        auto_reply_enabled: bool = False,
        auto_reply_message: str = DEFAULT_AUTO_REPLY,
        on_incoming_message: Callable[[str, str, int], None] | None = None,
    ) -> None:
        self.bot_token = bot_token.strip()
        self.auto_reply_enabled = auto_reply_enabled
        self.auto_reply_message = auto_reply_message or DEFAULT_AUTO_REPLY
        self.on_incoming_message = on_incoming_message

        self._running = False
        self._thread: threading.Thread | None = None
        self._last_update_id = 0

    def _endpoint(self, method: str) -> str:
        return f"{self.API_BASE}/bot{self.bot_token}/{method}"

    def verify_bot(self) -> tuple[bool, str]:
        """Verifies the official BotFather token via getMe."""
        if not self.bot_token:
            return False, "TELEGRAM_BOT_TOKEN kiritilmagan."
        try:
            with httpx.Client(timeout=8.0) as client:
                resp = client.get(self._endpoint("getMe"))
                data = resp.json()
            if resp.status_code == 200 and data.get("ok"):
                username = data["result"].get("username", "bot")
                return True, f"Telegram Bot ulandi: @{username}"
            return False, f"Telegram API xatosi: {data.get('description', resp.status_code)}"
        except Exception as exc:
            return False, f"Telegram serveriga ulanib bo'lmadi: {exc}"

    def send_message(self, chat_id: int | str, text: str, owner_confirmed: bool = False) -> tuple[bool, str]:
        """Sends an official Bot API message. Manual messages require owner confirmation."""
        if not owner_confirmed:
            return False, "Xabar yuborish uchun egasining tasdig'i talab qilinadi."
        return self._post_message(chat_id, text)

    def _post_message(self, chat_id: int | str, text: str) -> tuple[bool, str]:
        if not self.bot_token:
            return False, "TELEGRAM_BOT_TOKEN kiritilmagan."
        try:
            with httpx.Client(timeout=8.0) as client:
                resp = client.post(
                    self._endpoint("sendMessage"),
                    json={"chat_id": chat_id, "text": text},
                )
                data = resp.json()
            if resp.status_code == 200 and data.get("ok"):
                return True, "Xabar Telegram orqali yuborildi."
            return False, f"Yuborish xatosi: {data.get('description', resp.status_code)}"
        except Exception as exc:
            return False, f"Telegram tarmoq xatosi: {exc}"

    def process_update(self, update: dict[str, Any]) -> bool:
        """Processes one Telegram Bot API update dict. Returns True if auto-reply was sent."""
        msg = update.get("message") or {}
        chat = msg.get("chat") or {}
        chat_id = chat.get("id")
        sender = (msg.get("from") or {}).get("first_name") or "Foydalanuvchi"
        text = msg.get("text") or ""
        is_bot = bool((msg.get("from") or {}).get("is_bot"))

        if not chat_id or not text or is_bot:
            return False

        if self.on_incoming_message:
            self.on_incoming_message(sender, text, int(chat_id))

        if self.auto_reply_enabled:
            ok, _ = self._post_message(chat_id, self.auto_reply_message)
            return ok
        return False

    def start_polling(self) -> tuple[bool, str]:
        if self._running:
            return True, "Telegram polling allaqachon ishlamoqda."
        if not self.bot_token:
            return False, "TELEGRAM_BOT_TOKEN mavjud emas."
        self._running = True
        self._thread = threading.Thread(
            target=self._poll_loop, daemon=True, name="NovaTelegramPoll"
        )
        self._thread.start()
        return True, "Telegram Bot polling boshlandi."

    def stop_polling(self) -> None:
        self._running = False
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2.0)
        self._thread = None

    def _poll_loop(self) -> None:
        while self._running:
            try:
                with httpx.Client(timeout=25.0) as client:
                    resp = client.get(
                        self._endpoint("getUpdates"),
                        params={"offset": self._last_update_id + 1, "timeout": 20},
                    )
                    data = resp.json()
                if resp.status_code == 200 and data.get("ok"):
                    for update in data.get("result", []):
                        self._last_update_id = max(
                            self._last_update_id, int(update.get("update_id", 0))
                        )
                        self.process_update(update)
            except Exception as exc:
                logger.debug("Telegram polling error: %s", exc)
                time.sleep(3.0)
