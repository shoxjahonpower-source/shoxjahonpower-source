"""Official Meta Instagram Graph API Messaging integration for N.O.V.A.

Supported account types: Instagram Professional (Business or Creator) accounts
connected to an authorized Facebook Page using Meta's official Graph API.
Personal Instagram accounts are NOT supported by Meta's Messaging API, and this
module NEVER collects Instagram passwords or uses unofficial scraping.
"""

from __future__ import annotations

import logging
import threading
from typing import Any, Callable

try:
    import httpx
except Exception:  # pragma: no cover
    httpx = None

logger = logging.getLogger("nova.instagram")

DEFAULT_AUTO_REPLY = "Darknes online emas. Bir oz kuting! Javob berdi: N.O.V.A."


class InstagramOfficialClient:
    """Official Meta Graph API client & webhook handler for Instagram Professional DMs."""

    GRAPH_BASE = "https://graph.facebook.com/v21.0"

    def __init__(
        self,
        access_token: str = "",
        page_id: str = "",
        verify_token: str = "",
        auto_reply_enabled: bool = False,
        auto_reply_message: str = DEFAULT_AUTO_REPLY,
        on_incoming_message: Callable[[str, str], None] | None = None,
    ) -> None:
        self.access_token = access_token.strip()
        self.page_id = page_id.strip()
        self.verify_token = verify_token.strip()
        self.auto_reply_enabled = auto_reply_enabled
        self.auto_reply_message = auto_reply_message or DEFAULT_AUTO_REPLY
        self.on_incoming_message = on_incoming_message

        self._server: Any = None
        self._thread: threading.Thread | None = None

    def verify_account(self) -> tuple[bool, str]:
        """Checks connection to Meta Graph API for the configured Business Page."""
        if not self.access_token or not self.page_id:
            return (
                False,
                "INSTAGRAM_ACCESS_TOKEN va INSTAGRAM_PAGE_ID talab qilinadi (faqat Professional/Business akkauntlar).",
            )
        try:
            with httpx.Client(timeout=8.0) as client:
                resp = client.get(
                    f"{self.GRAPH_BASE}/{self.page_id}",
                    params={"fields": "id,name", "access_token": self.access_token},
                )
                data = resp.json()
            if resp.status_code == 200 and "id" in data:
                return True, f"Instagram Business Page ulandi: {data.get('name', data['id'])}"
            err = (data.get("error") or {}).get("message", resp.status_code)
            return False, f"Meta Graph API xatosi: {err}"
        except Exception as exc:
            return False, f"Meta API ulanish xatosi: {exc}"

    def send_message(
        self, recipient_igsid: str, text: str, owner_confirmed: bool = False
    ) -> tuple[bool, str]:
        if not owner_confirmed:
            return False, "Xabar yuborish uchun egasining tasdig'i talab qilinadi."
        return self._post_reply(recipient_igsid, text)

    def _post_reply(self, recipient_igsid: str, text: str) -> tuple[bool, str]:
        if not self.access_token or not self.page_id:
            return False, "Meta Graph API token yoki Page ID kiritilmagan."
        try:
            with httpx.Client(timeout=8.0) as client:
                resp = client.post(
                    f"{self.GRAPH_BASE}/{self.page_id}/messages",
                    params={"access_token": self.access_token},
                    json={
                        "recipient": {"id": recipient_igsid},
                        "message": {"text": text},
                    },
                )
                data = resp.json()
            if resp.status_code == 200:
                return True, "Instagram javobi yuborildi."
            err = (data.get("error") or {}).get("message", resp.status_code)
            return False, f"Meta Graph API xatosi: {err}"
        except Exception as exc:
            return False, f"Meta API tarmoq xatosi: {exc}"

    def handle_webhook_payload(self, payload: dict[str, Any]) -> int:
        """Handles official Meta webhook JSON events. Returns count of auto-replies sent."""
        replies_sent = 0
        for entry in payload.get("entry", []):
            for event in entry.get("messaging", []):
                sender_id = (event.get("sender") or {}).get("id")
                message_obj = event.get("message") or {}
                if message_obj.get("is_echo"):
                    continue
                text = message_obj.get("text") or ""
                if not sender_id or not text:
                    continue

                if self.on_incoming_message:
                    self.on_incoming_message(str(sender_id), str(text))

                if self.auto_reply_enabled:
                    ok, _ = self._post_reply(str(sender_id), self.auto_reply_message)
                    if ok:
                        replies_sent += 1
        return replies_sent

    def start_webhook_server(self, port: int = 8765) -> tuple[bool, str]:
        """Starts an optional local FastAPI webhook listener for Meta Graph API callbacks."""
        if self._thread and self._thread.is_alive():
            return True, f"Instagram webhook serveri {port}-portda ishlamoqda."
        try:
            import uvicorn
            from fastapi import FastAPI, HTTPException, Query, Request
            from fastapi.responses import PlainTextResponse
        except Exception as exc:
            return False, f"FastAPI/Uvicorn topilmadi: {exc}"

        app = FastAPI(title="N.O.V.A. Instagram Official Webhook")

        @app.get("/webhook/instagram")
        def verify_webhook(
            hub_mode: str = Query(default="", alias="hub.mode"),
            hub_verify_token: str = Query(default="", alias="hub.verify_token"),
            hub_challenge: str = Query(default="", alias="hub.challenge"),
        ) -> PlainTextResponse:
            if hub_mode == "subscribe" and self.verify_token and hub_verify_token == self.verify_token:
                return PlainTextResponse(hub_challenge)
            raise HTTPException(status_code=403, detail="Verification failed")

        @app.post("/webhook/instagram")
        async def receive_webhook(request: Request) -> dict[str, Any]:
            body = await request.json()
            count = self.handle_webhook_payload(body)
            return {"status": "ok", "auto_replies_sent": count}

        config = uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning")
        self._server = uvicorn.Server(config)
        self._thread = threading.Thread(
            target=self._server.run, daemon=True, name="NovaInstagramWebhook"
        )
        self._thread.start()
        return True, f"Instagram webhook http://127.0.0.1:{port}/webhook/instagram manzilida ishga tushdi."

    def stop_webhook_server(self) -> None:
        if self._server is not None:
            self._server.should_exit = True
