@echo off
setlocal enabledelayedexpansion

echo ============================================================
echo   N.O.V.A. — DARKNES ULTIMATE Standalone Windows Build
echo ============================================================

where python >nul 2>nul
if %errorlevel% neq 0 (
    echo [XATO] Build mashinasida Python 3.12+ topilmadi.
    echo Eslatma: Yakuniy foydalanuvchiga Python kerak bo'lmaydi,
    echo faqat ushbu .exe yig'uvchi kompyuterda Python bo'lishi kerak.
    exit /b 1
)

if not exist ".venv" (
    echo [1/6] Virtual muhit yaratilmoqda...
    python -m venv .venv
)

call .venv\Scripts\activate.bat

echo [2/6] Kutubxonalar o'rnatilmoqda...
python -m pip install --upgrade pip
pip install -r requirements.txt

echo [3/6] Windows ikonka yaratilmoqda...
python build_icon.py

echo [4/6] Avtomatlashtirilgan testlar ishga tushirilmoqda...
pytest -q
if %errorlevel% neq 0 (
    echo [XATO] Testlardan biri muvaffaqiyatsiz tugadi. Build to'xtatildi.
    exit /b 1
)

echo [5/6] PyInstaller orqali mustaqil Portable .exe yig'ilmoqda...
pyinstaller ^
  --noconfirm ^
  --clean ^
  --windowed ^
  --onefile ^
  --name "NOVA_Darknes_Ultimate" ^
  --icon "assets/nova_icon.ico" ^
  --collect-all vosk ^
  --collect-all mediapipe ^
  --collect-all edge_tts ^
  --collect-all google.genai ^
  --hidden-import keyring.backends.Windows ^
  --hidden-import pyttsx3.drivers.sapi5 ^
  --add-data "config/allowlist.json;config" ^
  --add-data "config/preferences.json;config" ^
  --add-data "config/memory.json;config" ^
  --add-data "assets;assets" ^
  main.py

if %errorlevel% neq 0 (
    echo [XATO] PyInstaller build muvaffaqiyatsiz tugadi.
    exit /b 1
)

echo [6/6] Inno Setup (agar o'rnatilgan bo'lsa) orqali Windows Installer yaratilmoqda...
where iscc >nul 2>nul
if %errorlevel% equ 0 (
    iscc installer.iss
    echo   Installer tayyor: dist\NOVA_Darknes_Setup.exe
) else (
    echo   [INFO] Inno Setup (iscc) topilmadi — faqat Portable .exe yaratildi.
)

echo ============================================================
echo   TAYYOR! Portable EXE: dist\NOVA_Darknes_Ultimate.exe
echo   Yakuniy foydalanuvchidan Python o'rnatish talab qilinmaydi.
echo ============================================================
pause
