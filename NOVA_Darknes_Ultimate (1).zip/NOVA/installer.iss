; Inno Setup Script for N.O.V.A. — DARKNES ULTIMATE Windows 10/11 Installer
; Packages the PyInstaller standalone executable (embedded Python + all dependencies)

#define MyAppName "N.O.V.A. — DARKNES ULTIMATE"
#define MyAppVersion "1.0.0"
#define MyAppPublisher "Darknes"
#define MyAppExeName "NOVA_Darknes_Ultimate.exe"

[Setup]
AppId={{8D4F63B2-6F9C-4E1C-9C89-A1E7F0B24C11}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\NOVA_Darknes_Ultimate
DefaultGroupName={#MyAppName}
AllowNoIcons=yes
OutputDir=dist
OutputBaseFilename=NOVA_Darknes_Setup
SetupIconFile=assets\nova_icon.ico
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional icons:"

[Files]
Source: "dist\{#MyAppExeName}"; DestDir: "{app}"; Flags: ignoreversion
Source: ".env.example"; DestDir: "{app}"; Flags: ignoreversion
Source: "README.md"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Launch {#MyAppName}"; Flags: nowait postinstall skipifsilent
