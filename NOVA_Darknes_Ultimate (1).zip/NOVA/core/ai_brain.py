"""Real ChatGPT-grade Uzbek AI Brain powered by Google Gemini API + Function Calling + Persistent Memory."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from config.settings import PREFERENCES_PATH, NovaConfig
from core.memory_store import MEMORY_PATH, MemoryStore

logger = logging.getLogger("nova.ai_brain")

try:
    from google import genai
    from google.genai import types
except Exception:  # pragma: no cover
    genai = None
    types = None


ToolExecutor = Callable[[str, dict[str, Any]], tuple[bool, str, str]]
# Returns (success, action_name, message)


@dataclass
class AiReply:
    text: str
    suggested_memory: tuple[str, str] | None = None  # (content, category)
    executed_tools: list[dict[str, Any]] = field(default_factory=list)
    error: str | None = None


class AiBrain:
    """Conversational Uzbek AI core with persistent memory, Gemini tool calling, and Vision."""

    def __init__(
        self,
        config: NovaConfig,
        preferences_path: Path = PREFERENCES_PATH,
        memory_path: Path = MEMORY_PATH,
        tool_executor: ToolExecutor | None = None,
    ) -> None:
        self.config = config
        self.preferences_path = preferences_path
        self.memory_store = MemoryStore(path=memory_path, owner_name=config.owner_name)
        self.tool_executor = tool_executor
        self._client: Any = None

    @property
    def history(self) -> list[dict[str, str]]:
        return [{"role": t.role, "text": t.text} for t in self.memory_store.conversation_history]

    @property
    def approved_preferences(self) -> list[str]:
        return [m.content for m in self.memory_store.list_memories()]

    def approve_and_save_preference(self, preference: str, category: str = "preference") -> bool:
        """Persists a memory/preference ONLY after explicit owner approval."""
        item = self.memory_store.add_memory(preference, category=category)
        return item is not None

    def _get_client(self) -> Any:
        if self._client is not None:
            return self._client
        api_key = self.config.get_gemini_api_key()
        if not api_key or genai is None:
            return None
        self._client = genai.Client(api_key=api_key)
        return self._client

    def reset_client(self) -> None:
        self._client = None

    def clear_history(self) -> None:
        self.memory_store.clear_history()

    def build_system_instruction(self) -> str:
        memories = self.memory_store.list_memories()
        if memories:
            mem_lines = "\n".join(f"- [{m.category}] {m.content}" for m in memories)
        else:
            mem_lines = "Hozircha tasdiqlangan shaxsiy xotira yozuvlari yo'q."

        return (
            f"Sen N.O.V.A. — DARKNES EDITION aqlli suhbatdosh va shaxsiy sun'iy intellekt yordamchisan.\n"
            f"Egasi va foydalanuvchi nomi: {self.config.owner_name}.\n"
            f"Asosiy muloqot tili: O'zbek tili (tabiiy, ravon, aqlli va ChatGPT darajasida foydali).\n\n"
            "Asosiy qobiliyatlar va qoidalar:\n"
            "1. Umumiy bilim, matematika, fizika, kimyo, dasturlash, texnologiya, g'oyalar yaratish va murakkab mavzularni "
            "sodda tilda tushuntirishda chuqur va aniq yordam ber.\n"
            "2. Kontekstni va oldingi savollarning davomini tushun.\n"
            "3. Agar biror faktni bilmasang, aniq ma'lumotga ega bo'lmasang yoki ruxsat etilmagan amalni bajarish imkonsiz bo'lsa, "
            "buni halol tan ol — hech qachon to'qima javob berma.\n"
            "4. Kompyuter boshqaruvi kerak bo'lganda (YouTube, Google, Instagram, Telegram, Notepad, Kalkulyator, kompyuter ovozi, soat), "
            "faqat taqdim etilgan ruxsatli vositalardan (tools) foydalan. Vositadan qaytgan haqiqiy natijaga tayan — agar vosita "
            "muvaffaqiyatsiz bo'lsa, 'bajarildi' deb aytma.\n"
            "5. Agar foydalanuvchi o'zi, loyihasi yoki afzalligi haqida muhim ma'lumotni eslab qolishni so'rasa, "
            "`propose_memory` vositasini chaqir.\n"
            "6. Javoblarni ovozda tinglash va o'qish uchun tushunarli, lo'nda va tabiiy o'zbek tilida yoz.\n\n"
            f"Saqlangan xotira va afzalliklar:\n{mem_lines}"
        )

    def _build_tool_declarations(self) -> list[Any]:
        if types is None:
            return []
        return [
            types.Tool(
                function_declarations=[
                    types.FunctionDeclaration(
                        name="open_website",
                        description="Opens an allowlisted website in the owner's browser.",
                        parameters=types.Schema(
                            type=types.Type.OBJECT,
                            properties={
                                "site": types.Schema(
                                    type=types.Type.STRING,
                                    description="Allowed site key: youtube, google, instagram, or telegram.",
                                )
                            },
                            required=["site"],
                        ),
                    ),
                    types.FunctionDeclaration(
                        name="search_google",
                        description="Searches Google in the browser for the given query.",
                        parameters=types.Schema(
                            type=types.Type.OBJECT,
                            properties={
                                "query": types.Schema(
                                    type=types.Type.STRING,
                                    description="Search query text.",
                                )
                            },
                            required=["query"],
                        ),
                    ),
                    types.FunctionDeclaration(
                        name="launch_app",
                        description="Launches an allowlisted Windows desktop application.",
                        parameters=types.Schema(
                            type=types.Type.OBJECT,
                            properties={
                                "app_key": types.Schema(
                                    type=types.Type.STRING,
                                    description="Allowed app key: notepad, calculator, or telegram.",
                                )
                            },
                            required=["app_key"],
                        ),
                    ),
                    types.FunctionDeclaration(
                        name="adjust_volume",
                        description="Controls the Windows computer master audio volume.",
                        parameters=types.Schema(
                            type=types.Type.OBJECT,
                            properties={
                                "direction": types.Schema(
                                    type=types.Type.STRING,
                                    description="Direction: up, down, mute, or unmute.",
                                )
                            },
                            required=["direction"],
                        ),
                    ),
                    types.FunctionDeclaration(
                        name="get_current_time",
                        description="Gets the current local time and date in Uzbek.",
                        parameters=types.Schema(
                            type=types.Type.OBJECT,
                            properties={},
                        ),
                    ),
                    types.FunctionDeclaration(
                        name="propose_memory",
                        description="Proposes saving an important user preference, project detail, or personal fact for owner approval.",
                        parameters=types.Schema(
                            type=types.Type.OBJECT,
                            properties={
                                "fact": types.Schema(
                                    type=types.Type.STRING,
                                    description="Concise fact to remember in Uzbek.",
                                ),
                                "category": types.Schema(
                                    type=types.Type.STRING,
                                    description="Category: preference, project, personal, or note.",
                                ),
                            },
                            required=["fact", "category"],
                        ),
                    ),
                ]
            )
        ]

    def ask(self, user_message: str) -> AiReply:
        """Sends a multi-turn query to Gemini with Function Calling and persistent memory."""
        client = self._get_client()
        if client is None:
            return AiReply(
                text=(
                    "AI moduli ulanmagan: GEMINI_API_KEY sozlanmagan yoki google-genai kutubxonasi topilmadi. "
                    "Iltimos, Sozlamalar oynasida API kalitini kiriting."
                ),
                error="MISSING_API_KEY",
            )

        self.memory_store.append_turn("user", user_message)
        recent = list(self.memory_store.conversation_history[-18:])
        while recent and recent[0].role != "user":
            recent.pop(0)

        contents: list[Any] = [
            types.Content(
                role="user" if turn.role == "user" else "model",
                parts=[types.Part.from_text(text=turn.text)],
            )
            for turn in recent
        ]

        tools = self._build_tool_declarations()
        executed_tools: list[dict[str, Any]] = []
        suggested_memory: tuple[str, str] | None = None

        try:
            response = client.models.generate_content(
                model=self.config.gemini_model,
                contents=contents,
                config=types.GenerateContentConfig(
                    system_instruction=self.build_system_instruction(),
                    tools=tools if tools else None,
                ),
            )

            # Handle Gemini Function Calling loop (single round of authorized tool invocations)
            function_calls = getattr(response, "function_calls", None) or []
            if function_calls:
                model_content = response.candidates[0].content
                fn_response_parts: list[Any] = []

                for call in function_calls:
                    fn_name = getattr(call, "name", "")
                    fn_args = dict(getattr(call, "args", None) or {})
                    call_id = getattr(call, "id", None)

                    if fn_name == "propose_memory":
                        fact = str(fn_args.get("fact", "")).strip()
                        cat = str(fn_args.get("category", "note")).strip()
                        if fact:
                            suggested_memory = (fact, cat)
                        tool_result = {
                            "success": True,
                            "message": f"Xotira taklifi tayyorlandi (egasining tasdig'i kutiladi): {fact}",
                        }
                    elif self.tool_executor is not None:
                        ok, action_name, msg = self.tool_executor(fn_name, fn_args)
                        executed_tools.append(
                            {
                                "tool": fn_name,
                                "action": action_name,
                                "args": fn_args,
                                "success": ok,
                                "message": msg,
                            }
                        )
                        tool_result = {"success": ok, "message": msg}
                    else:
                        tool_result = {
                            "success": False,
                            "message": "Vosita bajaruvchisi ulanmagan.",
                        }

                    fn_response_parts.append(
                        types.Part.from_function_response(
                            name=fn_name,
                            response=tool_result,
                        )
                    )

                followup_contents = [
                    *contents,
                    model_content,
                    types.Content(role="user", parts=fn_response_parts),
                ]
                response = client.models.generate_content(
                    model=self.config.gemini_model,
                    contents=followup_contents,
                    config=types.GenerateContentConfig(
                        system_instruction=self.build_system_instruction(),
                        tools=tools if tools else None,
                    ),
                )

            answer = (response.text or "").strip()
            if not answer:
                answer = "Kechirasiz, hozir javob shakllantirib bo'lmadi."

            self.memory_store.append_turn("model", answer)
            if suggested_memory is None:
                fallback_pref = self._detect_preference_candidate(user_message)
                if fallback_pref:
                    suggested_memory = (fallback_pref, "preference")

            return AiReply(
                text=answer,
                suggested_memory=suggested_memory,
                executed_tools=executed_tools,
            )
        except Exception as exc:
            logger.error("Gemini API error: %s", exc)
            return AiReply(
                text=f"AI xizmati bilan bog'lanishda xatolik yuz berdi: {exc}",
                error=str(exc),
            )

    def analyze_frame(
        self,
        jpeg_bytes: bytes,
        prompt: str = "Kamerada nimalarni ko'ryapsan? O'zbek tilida qisqacha tasvirlab ber.",
    ) -> AiReply:
        """Describes an explicit owner-requested camera snapshot using Gemini Vision."""
        client = self._get_client()
        if client is None:
            return AiReply(
                text="Kamera tahlili uchun GEMINI_API_KEY talab qilinadi.",
                error="MISSING_API_KEY",
            )

        try:
            response = client.models.generate_content(
                model=self.config.gemini_model,
                contents=[
                    types.Part.from_bytes(data=jpeg_bytes, mime_type="image/jpeg"),
                    types.Part.from_text(text=prompt),
                ],
                config=types.GenerateContentConfig(
                    system_instruction=self.build_system_instruction(),
                ),
            )
            return AiReply(text=(response.text or "").strip() or "Tasvirni tahlil qilib bo'lmadi.")
        except Exception as exc:
            logger.error("Gemini Vision error: %s", exc)
            return AiReply(text=f"Tasvir tahlilida xatolik: {exc}", error=str(exc))

    @staticmethod
    def _detect_preference_candidate(text: str) -> str | None:
        lower = text.lower()
        markers = ("eslab qol", "yodingda tut", "men yoqtiraman", "mening sevimli", "loyiham")
        if any(m in lower for m in markers):
            return text.strip()
        return None
