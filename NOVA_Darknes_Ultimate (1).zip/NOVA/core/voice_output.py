"""Interchangeable Uzbek Text-to-Speech (TTS) with instant speech interruption."""

from __future__ import annotations

import asyncio
import logging
import tempfile
import threading
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Callable

logger = logging.getLogger("nova.voice_output")

try:
    import edge_tts
except Exception:  # pragma: no cover
    edge_tts = None

try:
    import pygame
except Exception:  # pragma: no cover
    pygame = None

try:
    import pyttsx3
except Exception:  # pragma: no cover
    pyttsx3 = None


class BaseTTSEngine(ABC):
    """Abstract interface for interchangeable Uzbek speech synthesis providers."""

    name: str = "base"

    @abstractmethod
    def synthesize_to_file(self, text: str, voice: str, rate: str, out_path: Path) -> bool:
        """Generates audio file at out_path. Returns True on success."""


class EdgeUzbekTTSEngine(BaseTTSEngine):
    """Natural Uzbek neural speech using Microsoft Edge TTS (uz-UZ-MadinaNeural / uz-UZ-SardorNeural)."""

    name = "edge_tts"

    def synthesize_to_file(self, text: str, voice: str, rate: str, out_path: Path) -> bool:
        if edge_tts is None:
            return False

        async def _run() -> None:
            communicate = edge_tts.Communicate(text=text, voice=voice, rate=rate)
            await communicate.save(str(out_path))

        try:
            asyncio.run(_run())
            return out_path.exists() and out_path.stat().st_size > 0
        except Exception as exc:
            logger.warning("Edge TTS synthesis failed: %s", exc)
            return False


class Pyttsx3OfflineTTSEngine(BaseTTSEngine):
    """Offline fallback TTS via Windows SAPI5 / pyttsx3."""

    name = "pyttsx3_offline"

    def synthesize_to_file(self, text: str, voice: str, rate: str, out_path: Path) -> bool:
        if pyttsx3 is None:
            return False
        try:
            engine = pyttsx3.init()
            base_rate = 175
            if rate.startswith("+") and rate.endswith("%"):
                delta = int(rate[1:-1])
                base_rate = int(base_rate * (1 + delta / 100.0))
            elif rate.startswith("-") and rate.endswith("%"):
                delta = int(rate[1:-1])
                base_rate = int(base_rate * max(0.5, 1 - delta / 100.0))
            engine.setProperty("rate", base_rate)
            engine.save_to_file(text, str(out_path))
            engine.runAndWait()
            return out_path.exists() and out_path.stat().st_size > 0
        except Exception as exc:
            logger.warning("pyttsx3 synthesis failed: %s", exc)
            return False


class VoiceOutputManager:
    """Manages natural Uzbek TTS, configurable speed/voice, and instant interruption."""

    SUPPORTED_UZBEK_VOICES = [
        "uz-UZ-MadinaNeural",
        "uz-UZ-SardorNeural",
    ]

    def __init__(
        self,
        provider: str = "edge_tts",
        voice: str = "uz-UZ-MadinaNeural",
        rate: str = "+0%",
    ) -> None:
        self.provider = provider
        self.voice = voice
        self.rate = rate
        self._engines: dict[str, BaseTTSEngine] = {
            "edge_tts": EdgeUzbekTTSEngine(),
            "pyttsx3_offline": Pyttsx3OfflineTTSEngine(),
        }
        self._stop_event = threading.Event()
        self._speaking_lock = threading.Lock()
        self.is_speaking = False

        if pygame is not None:
            try:
                if not pygame.mixer.get_init():
                    pygame.mixer.init()
            except Exception as exc:
                logger.debug("pygame mixer init deferred/failed: %s", exc)

    def register_engine(self, key: str, engine: BaseTTSEngine) -> None:
        self._engines[key] = engine

    def interrupt(self) -> None:
        """Immediately halts active speech playback (barge-in support)."""
        self._stop_event.set()
        if pygame is not None:
            try:
                if pygame.mixer.get_init() and pygame.mixer.music.get_busy():
                    pygame.mixer.music.stop()
            except Exception:
                pass

    def speak(
        self,
        text: str,
        on_start: Callable[[], None] | None = None,
        on_finish: Callable[[], None] | None = None,
    ) -> bool:
        """Speaks text in Uzbek synchronously until finished or interrupted."""
        cleaned = text.strip()
        if not cleaned:
            return False

        with self._speaking_lock:
            self._stop_event.clear()
            self.is_speaking = True
            if on_start:
                on_start()

            try:
                with tempfile.TemporaryDirectory(prefix="nova_tts_") as tmpdir:
                    suffix = ".mp3" if self.provider == "edge_tts" else ".wav"
                    audio_path = Path(tmpdir) / f"speech{suffix}"

                    engine = self._engines.get(self.provider) or self._engines["pyttsx3_offline"]
                    ok = engine.synthesize_to_file(cleaned, self.voice, self.rate, audio_path)

                    if not ok and self.provider != "pyttsx3_offline":
                        # Fallback to offline Windows SAPI5 if internet/Edge TTS unavailable
                        audio_path = Path(tmpdir) / "speech_fallback.wav"
                        ok = self._engines["pyttsx3_offline"].synthesize_to_file(
                            cleaned, self.voice, self.rate, audio_path
                        )

                    if not ok:
                        return False

                    return self._play_file(audio_path)
            finally:
                self.is_speaking = False
                if on_finish:
                    on_finish()

    def _play_file(self, audio_path: Path) -> bool:
        if pygame is None:
            return False
        try:
            if not pygame.mixer.get_init():
                pygame.mixer.init()
            pygame.mixer.music.load(str(audio_path))
            pygame.mixer.music.play()
            while pygame.mixer.music.get_busy():
                if self._stop_event.is_set():
                    pygame.mixer.music.stop()
                    return False
                pygame.time.Clock().tick(30)
            return True
        except Exception as exc:
            logger.warning("Audio playback error: %s", exc)
            return False
