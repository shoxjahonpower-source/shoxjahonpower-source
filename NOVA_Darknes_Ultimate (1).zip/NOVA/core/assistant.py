"""Main N.O.V.A. state machine coordinating wake-word, voice loop, AI tool calling, and memory."""

from __future__ import annotations

import logging
import threading
from enum import Enum
from typing import Any, Callable

from config.settings import NovaConfig
from core.ai_brain import AiBrain
from core.command_router import CommandRouter
from core.voice_input import VoiceInputManager
from core.voice_output import VoiceOutputManager
from core.wake_word import WakeWordDetector

logger = logging.getLogger("nova.assistant")

try:
    import sounddevice as sd
    import numpy as np
except Exception:  # pragma: no cover
    sd = None
    np = None


class AssistantState(str, Enum):
    SLEEP = "SLEEP"
    ACTIVE = "ACTIVE"
    LISTENING = "LISTENING"
    THINKING = "THINKING"
    SPEAKING = "SPEAKING"


class NovaAssistant:
    """Coordinates N.O.V.A.'s voice-first Uzbek assistant loop with AI tool calling."""

    def __init__(
        self,
        config: NovaConfig,
        wake_detector: WakeWordDetector,
        voice_input: VoiceInputManager,
        voice_output: VoiceOutputManager,
        ai_brain: AiBrain,
        command_router: CommandRouter,
        on_state_change: Callable[[AssistantState], None] | None = None,
        on_message: Callable[[str, str], None] | None = None,
        on_command_log: Callable[[str, str, bool], None] | None = None,
        on_audio_level: Callable[[float], None] | None = None,
        on_memory_proposal: Callable[[str, str], None] | None = None,
    ) -> None:
        self.config = config
        self.wake_detector = wake_detector
        self.voice_input = voice_input
        self.voice_output = voice_output
        self.ai_brain = ai_brain
        self.command_router = command_router

        # Connect AiBrain's authorized tool executor directly to CommandRouter
        self.ai_brain.tool_executor = self._execute_ai_tool

        self.on_state_change = on_state_change
        self.on_message = on_message
        self.on_command_log = on_command_log
        self.on_audio_level = on_audio_level
        self.on_memory_proposal = on_memory_proposal

        self.state = AssistantState.SLEEP
        self._running = False
        self._conversation_thread: threading.Thread | None = None
        self._active_lock = threading.Lock()
        self._barge_in_stop = threading.Event()

    def _execute_ai_tool(self, tool_name: str, args: dict[str, Any]) -> tuple[bool, str, str]:
        res = self.command_router.execute_tool(tool_name, args)
        return res.success, res.action, res.response_text

    def _set_state(self, new_state: AssistantState) -> None:
        self.state = new_state
        if self.on_state_change:
            self.on_state_change(new_state)

    def _emit_message(self, sender: str, text: str) -> None:
        if self.on_message:
            self.on_message(sender, text)

    def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._set_state(AssistantState.SLEEP)
        self._start_wake_listener()

    def stop(self) -> None:
        self._running = False
        self._barge_in_stop.set()
        self.voice_output.interrupt()
        self.wake_detector.stop_listening()

    def set_mic_muted(self, muted: bool) -> None:
        self.config.microphone_muted = muted
        self.wake_detector.set_muted(muted)
        self.voice_input.set_muted(muted)

    def _start_wake_listener(self) -> None:
        if not self._running or self.state != AssistantState.SLEEP:
            return
        self.wake_detector.start_listening(
            on_wake=lambda _phrase: self.wake_up(),
            on_level=self.on_audio_level,
        )

    def wake_up(self) -> None:
        """Transitions from SLEEP to ACTIVE and starts continuous Uzbek voice loop."""
        with self._active_lock:
            if self.state != AssistantState.SLEEP:
                return
            self.wake_detector.stop_listening()
            self._set_state(AssistantState.ACTIVE)

        greeting = f"Assalomu alaykum, {self.config.owner_name}. Sizni eshitaman."
        self._emit_message("N.O.V.A.", greeting)
        self._speak(greeting)

        if self._running and (
            self._conversation_thread is None or not self._conversation_thread.is_alive()
        ):
            self._conversation_thread = threading.Thread(
                target=self._active_loop,
                daemon=True,
                name="NovaConversationLoop",
            )
            self._conversation_thread.start()

    def go_to_sleep(self) -> None:
        """Transitions from ACTIVE back to SLEEP mode."""
        self.voice_output.interrupt()
        self._set_state(AssistantState.SLEEP)
        farewell = f"Xo'p, {self.config.owner_name}. Kutish rejimiga o'tdim."
        self._emit_message("N.O.V.A.", farewell)
        self._speak(farewell)
        self._start_wake_listener()

    def interrupt_speech(self) -> None:
        self._barge_in_stop.set()
        self.voice_output.interrupt()
        if self.state == AssistantState.SPEAKING:
            self._set_state(AssistantState.ACTIVE)

    def handle_user_utterance(self, text: str) -> str:
        """Processes one text/voice input while enforcing SLEEP vs ACTIVE rules."""
        cleaned = text.strip()
        if not cleaned:
            return ""

        if self.state == AssistantState.SLEEP:
            if self.wake_detector.matches_wake_word(cleaned):
                self.wake_up()
                return f"Assalomu alaykum, {self.config.owner_name}. Sizni eshitaman."
            return ""

        self._emit_message(self.config.owner_name, cleaned)

        if self.wake_detector.matches_sleep_phrase(cleaned):
            self.go_to_sleep()
            return f"Xo'p, {self.config.owner_name}. Kutish rejimiga o'tdim."

        self._set_state(AssistantState.THINKING)
        cmd_res = self.command_router.route(cleaned)
        if cmd_res.handled:
            if self.on_command_log:
                self.on_command_log(cleaned, cmd_res.action, cmd_res.success)
            self._emit_message("N.O.V.A.", cmd_res.response_text)
            self._speak(cmd_res.response_text)
            if self.state != AssistantState.SLEEP:
                self._set_state(AssistantState.ACTIVE)
            return cmd_res.response_text

        # Route general intelligence & intent-based tool selection through AiBrain
        reply = self.ai_brain.ask(cleaned)
        for tool_exec in getattr(reply, "executed_tools", []):
            if self.on_command_log:
                self.on_command_log(
                    cleaned,
                    str(tool_exec.get("action", tool_exec.get("tool", "ai_tool"))),
                    bool(tool_exec.get("success", False)),
                )

        self._emit_message("N.O.V.A.", reply.text)
        suggested = getattr(reply, "suggested_memory", None)
        if suggested and self.on_memory_proposal:
            self.on_memory_proposal(suggested[0], suggested[1])

        self._speak(reply.text)
        if self.state != AssistantState.SLEEP:
            self._set_state(AssistantState.ACTIVE)
        return reply.text

    def _speak(self, text: str) -> None:
        prev_state = self.state
        self._set_state(AssistantState.SPEAKING)
        self._barge_in_stop.clear()

        monitor_thread = None
        if sd is not None and np is not None and not self.config.microphone_muted:
            monitor_thread = threading.Thread(
                target=self._monitor_barge_in,
                daemon=True,
                name="NovaBargeInMonitor",
            )
            monitor_thread.start()

        self.voice_output.speak(text)
        self._barge_in_stop.set()
        if monitor_thread and monitor_thread.is_alive():
            monitor_thread.join(timeout=0.3)

        if self.state == AssistantState.SPEAKING:
            self._set_state(prev_state if prev_state != AssistantState.SPEAKING else AssistantState.ACTIVE)

    def _monitor_barge_in(self) -> None:
        """Detects sustained voice energy while N.O.V.A. is speaking to allow natural interruption."""
        if sd is None or np is None:
            return
        sample_rate = 16000
        block_size = int(sample_rate * 0.15)
        consecutive_loud = 0
        try:
            with sd.RawInputStream(
                samplerate=sample_rate,
                blocksize=block_size,
                dtype="int16",
                channels=1,
            ) as stream:
                while not self._barge_in_stop.is_set() and self.voice_output.is_speaking:
                    if self.config.microphone_muted:
                        break
                    data, _ = stream.read(block_size)
                    samples = np.frombuffer(bytes(data), dtype=np.int16).astype(np.float32) / 32768.0
                    rms = float(np.sqrt(np.mean(np.square(samples)))) if samples.size else 0.0
                    if self.on_audio_level:
                        self.on_audio_level(min(1.0, rms * 8.0))
                    if rms > 0.065:
                        consecutive_loud += 1
                        if consecutive_loud >= 2:  # ~300ms sustained owner speech
                            self.voice_output.interrupt()
                            break
                    else:
                        consecutive_loud = 0
        except Exception:
            pass

    def _active_loop(self) -> None:
        while self._running and self.state != AssistantState.SLEEP:
            if self.config.microphone_muted:
                threading.Event().wait(0.25)
                continue

            self._set_state(AssistantState.LISTENING)
            transcript = self.voice_input.listen(
                timeout=6.0,
                phrase_time_limit=12.0,
                on_level=self.on_audio_level,
            )
            if not self._running or self.state == AssistantState.SLEEP:
                break
            if transcript:
                self.handle_user_utterance(transcript)
            else:
                self._set_state(AssistantState.ACTIVE)
