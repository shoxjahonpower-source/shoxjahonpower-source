"""Safe Uzbek voice command router & AI tool executor with explicit allowlist."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Callable

from core.wake_word import normalize_uzbek_phrase


@dataclass
class CommandResult:
    handled: bool
    action: str
    response_text: str
    requires_confirmation: bool = False
    confirmation_prompt: str = ""
    payload: dict[str, Any] = field(default_factory=dict)
    success: bool = True


ConfirmationCallback = Callable[[str], bool]


class CommandRouter:
    """Validates and executes safe allowlisted tools for both direct voice commands and Gemini tool calls.

    Never executes arbitrary AI-generated shell/terminal commands.
    """

    UNSAFE_SHELL_PATTERNS = (
        "rm -rf",
        "del /f",
        "format ",
        "powershell",
        "cmd.exe",
        "subprocess",
        "reg delete",
        "shutdown /s",
    )

    OPEN_VERBS = ("och", "ishga tushir", "kir", "yoq", "yurgiz")

    def __init__(
        self,
        computer_control: Any,
        browser_control: Any,
        owner_name: str = "Darknes",
        confirm_callback: ConfirmationCallback | None = None,
    ) -> None:
        self.computer = computer_control
        self.browser = browser_control
        self.owner_name = owner_name
        self.confirm_callback = confirm_callback

    def _confirm(self, message: str) -> bool:
        if self.confirm_callback is None:
            return False
        return bool(self.confirm_callback(message))

    def execute_tool(self, tool_name: str, args: dict[str, Any] | None = None) -> CommandResult:
        """Executes an authorized, allowlisted tool requested by the Gemini AI Brain."""
        params = args or {}

        if tool_name == "open_website":
            site = str(params.get("site", "")).strip().lower()
            if site not in ("youtube", "google", "instagram", "telegram"):
                return CommandResult(
                    handled=True,
                    action="invalid_site",
                    success=False,
                    response_text=f"'{site}' sayti ruxsat etilgan ro'yxatda yo'q.",
                )
            ok, msg = self.browser.open_allowed_url(site)
            return CommandResult(
                handled=True,
                action=f"open_{site}",
                success=ok,
                response_text=msg,
                payload={"site": site},
            )

        if tool_name == "search_google":
            query = str(params.get("query", "")).strip()
            ok, msg = self.browser.search_google(query)
            return CommandResult(
                handled=True,
                action="google_search",
                success=ok,
                response_text=msg,
                payload={"query": query},
            )

        if tool_name == "launch_app":
            app_key = str(params.get("app_key", "")).strip().lower()
            if app_key not in ("notepad", "calculator", "telegram"):
                return CommandResult(
                    handled=True,
                    action="invalid_app",
                    success=False,
                    response_text=f"'{app_key}' dasturi ruxsat etilgan ro'yxatda yo'q.",
                )
            ok, msg = self.computer.launch_allowed_app(app_key)
            return CommandResult(
                handled=True,
                action=f"open_{app_key}",
                success=ok,
                response_text=msg,
                payload={"app_key": app_key},
            )

        if tool_name == "adjust_volume":
            direction = str(params.get("direction", "")).strip().lower()
            if direction == "down":
                ok, msg = self.computer.adjust_volume(-0.15)
                return CommandResult(handled=True, action="volume_down", success=ok, response_text=msg)
            if direction == "up":
                ok, msg = self.computer.adjust_volume(0.15)
                return CommandResult(handled=True, action="volume_up", success=ok, response_text=msg)
            if direction == "mute":
                ok, msg = self.computer.set_mute(True)
                return CommandResult(handled=True, action="volume_mute", success=ok, response_text=msg)
            if direction == "unmute":
                ok, msg = self.computer.set_mute(False)
                return CommandResult(handled=True, action="volume_unmute", success=ok, response_text=msg)
            return CommandResult(
                handled=True,
                action="invalid_volume_direction",
                success=False,
                response_text="Noto'g'ri ovoz yo'nalishi.",
            )

        if tool_name == "get_current_time":
            msg = self.computer.get_time_uzbek()
            return CommandResult(handled=True, action="get_time", success=True, response_text=msg)

        return CommandResult(
            handled=True,
            action="unknown_tool",
            success=False,
            response_text=f"'{tool_name}' vositasi ruxsat etilmagan.",
        )

    def route(self, raw_text: str) -> CommandResult:
        """Fast deterministic check for safety rules and explicit Uzbek system commands.

        Returns handled=False for general questions and natural-language intents so
        AiBrain (with Gemini Function Calling) can reason or select an authorized tool.
        """
        text = raw_text.strip()
        norm = normalize_uzbek_phrase(text)
        if not norm:
            return CommandResult(handled=False, action="empty", response_text="")

        # Block unsafe arbitrary command injection attempts
        if any(p in text.lower() for p in self.UNSAFE_SHELL_PATTERNS):
            return CommandResult(
                handled=True,
                action="blocked_unsafe_command",
                success=False,
                response_text=(
                    f"Kechirasiz, {self.owner_name}. Xavfsizlik siyosatiga ko'ra tizim terminaliga "
                    "to'g'ridan-to'g'ri buyruqlar bajarish taqiqlangan."
                ),
            )

        # Private credentials or hidden files request
        if any(k in norm for k in ("parolni korsat", "parollarni och", "maxfiy fayl")):
            return CommandResult(
                handled=True,
                action="denied_private_access",
                success=False,
                response_text=(
                    "Xavfsizlik qoidalariga ko'ra, parollar yoki shaxsiy maxfiy fayllarga "
                    "alohida ruxsatsiz kirish mumkin emas."
                ),
            )

        # File deletion always requires explicit owner confirmation
        if any(k in norm for k in ("faylni ochir", "fayl ochir", "delete")):
            confirmed = self._confirm(
                "Diqqat! Faylni o'chirish amali so'raldi. Ruxsat berasizmi?"
            )
            if not confirmed:
                return CommandResult(
                    handled=True,
                    action="delete_file_denied",
                    requires_confirmation=True,
                    success=False,
                    response_text="Faylni o'chirish uchun ruxsat berilmadi. Amal bekor qilindi.",
                )
            return CommandResult(
                handled=True,
                action="delete_file_confirmed",
                requires_confirmation=True,
                response_text="Ruxsat tasdiqlandi, lekin xavfsiz fayl yo'li ko'rsatilmagan.",
            )

        # Help command
        if any(k in norm for k in ("yordam ber", "nimalar qila olasan", "buyruqlar")):
            return CommandResult(
                handled=True,
                action="help",
                response_text=(
                    f"Albatta, {self.owner_name}. Men har qanday umumiy bilim, matematika, fan, "
                    "dasturlash va texnologiya savollariga javob bera olaman, avvalgi suhbatlar va "
                    "tasdiqlangan xotirani eslab qolaman, shuningdek YouTube, Telegram, Instagram, Google, "
                    "Google qidiruvi, Notepad, Kalkulyator, kompyuter ovozi hamda kamerani xavfsiz boshqara olaman."
                ),
            )

        # Time & date
        if any(k in norm for k in ("vaqtni ayt", "soat necha", "soat nechchi", "bugun nechanchi")):
            return self.execute_tool("get_current_time")

        # Google search: "Google'dan Minecraft deb qidir."
        search_match = re.search(
            r"(?:google|gugl)\s*(?:dan)?\s+(.+?)\s+(?:deb\s+)?(?:qidir|izla)",
            norm,
        )
        if search_match:
            query = search_match.group(1).strip()
            return self.execute_tool("search_google", {"query": query})

        has_open_verb = any(v in norm for v in self.OPEN_VERBS)

        # Open websites & allowlisted apps
        if ("youtube" in norm or "yutub" in norm) and has_open_verb:
            return self.execute_tool("open_website", {"site": "youtube"})

        if "instagram" in norm and has_open_verb:
            return self.execute_tool("open_website", {"site": "instagram"})

        if "google" in norm and has_open_verb and "qidir" not in norm and "izla" not in norm:
            return self.execute_tool("open_website", {"site": "google"})

        if "telegram" in norm and has_open_verb:
            return self.execute_tool("launch_app", {"app_key": "telegram"})

        if ("notepad" in norm or "bloknot" in norm) and has_open_verb:
            return self.execute_tool("launch_app", {"app_key": "notepad"})

        if ("kalkulyator" in norm or "calculator" in norm or "hisoblagich" in norm) and has_open_verb:
            return self.execute_tool("launch_app", {"app_key": "calculator"})

        # Volume controls
        if "ovoz" in norm and any(v in norm for v in ("pasaytir", "kamaytir", "tushir")):
            return self.execute_tool("adjust_volume", {"direction": "down"})

        if "ovoz" in norm and any(v in norm for v in ("kotar", "oshir", "baland")):
            return self.execute_tool("adjust_volume", {"direction": "up"})

        if "ovoz" in norm and any(v in norm for v in ("ochir", "mute", "jim")):
            return self.execute_tool("adjust_volume", {"direction": "mute"})

        return CommandResult(handled=False, action="ai_chat", response_text="")
