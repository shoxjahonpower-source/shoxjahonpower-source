"""Offline wake-word & sleep-phrase detection for N.O.V.A.

Never sends continuous microphone audio to cloud services while sleeping.
Uses local energy/VAD gating and an offline Vosk acoustic recognizer when available,
paired with Uzbek phonetic normalization and fuzzy matching.
"""

from __future__ import annotations

import json
import logging
import re
import threading
from difflib import SequenceMatcher
from pathlib import Path
from typing import Callable

try:
    import numpy as np
except Exception:  # pragma: no cover
    np = None

logger = logging.getLogger("nova.wake_word")

try:
    import sounddevice as sd
except Exception:  # pragma: no cover
    sd = None

try:
    from vosk import KaldiRecognizer, Model as VoskModel, SetLogLevel
    SetLogLevel(-1)
except Exception:  # pragma: no cover
    KaldiRecognizer = None
    VoskModel = None


def normalize_uzbek_phrase(text: str) -> str:
    """Normalizes apostrophes, punctuation, and whitespace for Uzbek wake/sleep matching."""
    cleaned = text.lower().strip()
    for ch in ("'", "’", "‘", "ʻ", "`", "ʼ"):
        cleaned = cleaned.replace(ch, "")
    cleaned = re.sub(r"[^a-z0-9\u0400-\u04ff\s]", " ", cleaned)
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    return cleaned


class WakeWordDetector:
    """Detects wake word ('N.O.V.A., uyg'on!') and sleep command ('N.O.V.A., bo'shsan.') offline."""

    def __init__(
        self,
        wake_phrase: str = "N.O.V.A., uyg'on!",
        sleep_phrase: str = "N.O.V.A., bo'shsan.",
        vosk_model_path: str | Path | None = None,
        extra_wake_aliases: list[str] | None = None,
        extra_sleep_aliases: list[str] | None = None,
        sample_rate: int = 16000,
        energy_threshold: float = 0.012,
    ) -> None:
        self.sample_rate = sample_rate
        self.energy_threshold = energy_threshold
        self.muted = False

        self.wake_targets = self._build_targets(
            wake_phrase,
            extra_wake_aliases
            or [
                "nova uygon",
                "n o v a uygon",
                "nova uygan",
                "salom nova",
            ],
        )
        self.sleep_targets = self._build_targets(
            sleep_phrase,
            extra_sleep_aliases
            or [
                "nova boshsan",
                "n o v a boshsan",
                "nova uxlagin",
                "uxla nova",
            ],
        )

        self._vosk_model = None
        self._recognizer = None
        if vosk_model_path and VoskModel is not None:
            model_dir = Path(vosk_model_path)
            if model_dir.exists() and model_dir.is_dir():
                try:
                    self._vosk_model = VoskModel(str(model_dir))
                    self._recognizer = KaldiRecognizer(self._vosk_model, self.sample_rate)
                    logger.info("Offline Vosk wake-word model loaded from %s", model_dir)
                except Exception as exc:
                    logger.warning("Failed to load Vosk model (%s): %s", model_dir, exc)

        self._running = False
        self._thread: threading.Thread | None = None

    @staticmethod
    def _build_targets(primary: str, aliases: list[str]) -> list[str]:
        targets = {normalize_uzbek_phrase(primary)}
        for alias in aliases:
            norm = normalize_uzbek_phrase(alias)
            if norm:
                targets.add(norm)
        return sorted(t for t in targets if t)

    @property
    def offline_model_ready(self) -> bool:
        return self._recognizer is not None

    def matches_wake_word(self, transcript: str) -> bool:
        """Returns True if transcript matches configured Uzbek wake word."""
        norm = normalize_uzbek_phrase(transcript)
        if not norm:
            return False

        # Direct substring match for core phrase
        if "nova" in norm and any(k in norm for k in ("uygon", "uygan", "uygonin", "tur")):
            return True

        for target in self.wake_targets:
            if target in norm:
                return True
            if SequenceMatcher(None, norm, target).ratio() >= 0.78:
                return True
        return False

    def matches_sleep_phrase(self, transcript: str) -> bool:
        """Returns True if transcript matches configured Uzbek sleep command."""
        norm = normalize_uzbek_phrase(transcript)
        if not norm:
            return False

        if "nova" in norm and any(k in norm for k in ("boshsan", "uxla", "kutish", "dam ol")):
            return True

        for target in self.sleep_targets:
            if target in norm:
                return True
            if SequenceMatcher(None, norm, target).ratio() >= 0.78:
                return True
        return False

    def set_muted(self, muted: bool) -> None:
        self.muted = muted

    def start_listening(
        self,
        on_wake: Callable[[str], None],
        on_level: Callable[[float], None] | None = None,
        on_status: Callable[[str], None] | None = None,
    ) -> None:
        """Starts background offline wake-word loop. Audio never leaves the device."""
        if self._running:
            return
        if sd is None:
            if on_status:
                on_status("Mikrofon kutubxonasi (sounddevice) topilmadi.")
            return

        self._running = True
        self._thread = threading.Thread(
            target=self._listen_loop,
            args=(on_wake, on_level, on_status),
            daemon=True,
            name="NovaWakeWordThread",
        )
        self._thread.start()

    def stop_listening(self) -> None:
        self._running = False
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=1.5)
        self._thread = None

    def _listen_loop(
        self,
        on_wake: Callable[[str], None],
        on_level: Callable[[float], None] | None,
        on_status: Callable[[str], None] | None,
    ) -> None:
        block_size = int(self.sample_rate * 0.25)  # 250ms chunks

        try:
            with sd.RawInputStream(
                samplerate=self.sample_rate,
                blocksize=block_size,
                dtype="int16",
                channels=1,
            ) as stream:
                if on_status:
                    mode_msg = (
                        "Oflayn Vosk wake-word faol"
                        if self.offline_model_ready
                        else "Oflayn VAD kutish rejimi (Vosk modeli topilmadi)"
                    )
                    on_status(mode_msg)

                while self._running:
                    data, _overflowed = stream.read(block_size)
                    if self.muted:
                        if on_level:
                            on_level(0.0)
                        continue

                    samples = np.frombuffer(bytes(data), dtype=np.int16).astype(np.float32) / 32768.0
                    rms = float(np.sqrt(np.mean(np.square(samples)))) if samples.size else 0.0
                    if on_level:
                        on_level(min(1.0, rms * 8.0))

                    # Local VAD gate: discard silence/background noise before acoustic recognition
                    if rms < self.energy_threshold:
                        continue

                    if self._recognizer is not None:
                        accepted = self._recognizer.AcceptWaveform(bytes(data))
                        result_json = (
                            self._recognizer.Result()
                            if accepted
                            else self._recognizer.PartialResult()
                        )
                        try:
                            payload = json.loads(result_json)
                        except json.JSONDecodeError:
                            payload = {}
                        phrase = payload.get("text") or payload.get("partial") or ""
                        if phrase and self.matches_wake_word(phrase):
                            self._recognizer.Reset()
                            on_wake(phrase)
        except Exception as exc:
            logger.error("Wake-word audio stream error: %s", exc)
            if on_status:
                on_status(f"Mikrofon xatoligi: {exc}")
        finally:
            self._running = False
