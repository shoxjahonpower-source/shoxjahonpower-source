"""Interchangeable Speech-to-Text (STT) module for Uzbek & multilingual commands."""

from __future__ import annotations

import json
import logging
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Callable

try:
    import numpy as np
except Exception:  # pragma: no cover
    np = None

logger = logging.getLogger("nova.voice_input")

try:
    import speech_recognition as sr
except Exception:  # pragma: no cover
    sr = None

try:
    import sounddevice as sd
except Exception:  # pragma: no cover
    sd = None

try:
    from vosk import KaldiRecognizer, Model as VoskModel
except Exception:  # pragma: no cover
    KaldiRecognizer = None
    VoskModel = None


class BaseSTTEngine(ABC):
    """Abstract interface for interchangeable Uzbek speech recognition engines."""

    name: str = "base"

    @abstractmethod
    def listen_once(
        self,
        timeout: float = 6.0,
        phrase_time_limit: float = 12.0,
        on_level: Callable[[float], None] | None = None,
    ) -> str | None:
        """Captures one spoken utterance and returns recognized text or None."""


class VoskOfflineSTTEngine(BaseSTTEngine):
    """Fully offline STT using local Vosk acoustic model."""

    name = "vosk_offline"

    def __init__(self, model_path: str | Path, sample_rate: int = 16000) -> None:
        self.sample_rate = sample_rate
        self.model_path = Path(model_path)
        self._model = None
        if VoskModel is not None and self.model_path.exists():
            try:
                self._model = VoskModel(str(self.model_path))
            except Exception as exc:
                logger.warning("Vosk offline STT load failed: %s", exc)

    @property
    def is_available(self) -> bool:
        return self._model is not None and sd is not None

    def listen_once(
        self,
        timeout: float = 6.0,
        phrase_time_limit: float = 12.0,
        on_level: Callable[[float], None] | None = None,
    ) -> str | None:
        if not self.is_available or self._model is None or sd is None or KaldiRecognizer is None:
            return None

        recognizer = KaldiRecognizer(self._model, self.sample_rate)
        block_size = int(self.sample_rate * 0.2)
        max_blocks = int((timeout + phrase_time_limit) / 0.2)
        silent_blocks = 0
        speech_started = False

        with sd.RawInputStream(
            samplerate=self.sample_rate,
            blocksize=block_size,
            dtype="int16",
            channels=1,
        ) as stream:
            for _ in range(max_blocks):
                data, _ = stream.read(block_size)
                raw = bytes(data)
                samples = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
                rms = float(np.sqrt(np.mean(np.square(samples)))) if samples.size else 0.0
                if on_level:
                    on_level(min(1.0, rms * 8.0))

                if rms > 0.015:
                    speech_started = True
                    silent_blocks = 0
                elif speech_started:
                    silent_blocks += 1

                if recognizer.AcceptWaveform(raw):
                    res = json.loads(recognizer.Result())
                    text = (res.get("text") or "").strip()
                    if text:
                        return text

                if speech_started and silent_blocks >= 6:  # ~1.2s trailing silence
                    break
                if not speech_started and silent_blocks > int(timeout / 0.2):
                    break

        final = json.loads(recognizer.FinalResult())
        text = (final.get("text") or "").strip()
        return text or None


class GoogleWebSTTEngine(BaseSTTEngine):
    """Online Uzbek speech recognition via SpeechRecognition (uz-UZ) with ambient noise calibration."""

    name = "google_web"

    def __init__(self, language: str = "uz-UZ") -> None:
        self.language = language
        self._calibrated = False

    @property
    def is_available(self) -> bool:
        return sr is not None

    def listen_once(
        self,
        timeout: float = 6.0,
        phrase_time_limit: float = 12.0,
        on_level: Callable[[float], None] | None = None,
    ) -> str | None:
        if sr is None:
            return None

        recognizer = sr.Recognizer()
        recognizer.dynamic_energy_threshold = True
        recognizer.pause_threshold = 0.9
        audio = None

        try:
            with sr.Microphone() as source:
                if not self._calibrated:
                    recognizer.adjust_for_ambient_noise(source, duration=0.6)
                    self._calibrated = True
                if on_level:
                    on_level(0.35)
                audio = recognizer.listen(
                    source, timeout=timeout, phrase_time_limit=phrase_time_limit
                )
        except Exception as exc:
            logger.debug("sr.Microphone unavailable or timed out (%s), trying sounddevice", exc)
            audio = self._capture_via_sounddevice(timeout, phrase_time_limit, on_level)
        finally:
            if on_level:
                on_level(0.0)

        if audio is None:
            return None

        try:
            text = recognizer.recognize_google(audio, language=self.language)
            return text.strip() if text else None
        except sr.UnknownValueError:
            return None
        except Exception as exc:
            logger.warning("Google STT error: %s", exc)
            return None

    def _capture_via_sounddevice(
        self,
        timeout: float,
        phrase_time_limit: float,
        on_level: Callable[[float], None] | None,
    ) -> Any:
        if sr is None or sd is None or np is None:
            return None
        sample_rate = 16000
        block_size = int(sample_rate * 0.15)
        max_blocks = int((timeout + phrase_time_limit) / 0.15)
        frames: list[bytes] = []
        speech_started = False
        silent_blocks = 0

        try:
            with sd.RawInputStream(
                samplerate=sample_rate,
                blocksize=block_size,
                dtype="int16",
                channels=1,
            ) as stream:
                for _ in range(max_blocks):
                    data, _ = stream.read(block_size)
                    raw = bytes(data)
                    samples = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
                    rms = float(np.sqrt(np.mean(np.square(samples)))) if samples.size else 0.0
                    if on_level:
                        on_level(min(1.0, rms * 8.0))
                    if rms > 0.018:
                        speech_started = True
                        silent_blocks = 0
                        frames.append(raw)
                    elif speech_started:
                        silent_blocks += 1
                        frames.append(raw)
                        if silent_blocks >= 7:
                            break
                    else:
                        silent_blocks += 1
                        if silent_blocks > int(timeout / 0.15):
                            break
        except Exception as exc:
            logger.debug("sounddevice capture failed: %s", exc)
            return None

        if not speech_started or not frames:
            return None
        return sr.AudioData(b"".join(frames), sample_rate, 2)


class VoiceInputManager:
    """Manages interchangeable STT engines and noise-gated barge-in monitoring."""

    def __init__(
        self,
        provider: str = "hybrid",
        vosk_model_path: str | Path = "assets/models/vosk-model-small-uz-0.22",
        language: str = "uz-UZ",
    ) -> None:
        self.muted = False
        self.engines: dict[str, BaseSTTEngine] = {
            "vosk_offline": VoskOfflineSTTEngine(vosk_model_path),
            "google_web": GoogleWebSTTEngine(language=language),
        }
        self.provider = provider

    def register_engine(self, key: str, engine: BaseSTTEngine) -> None:
        self.engines[key] = engine

    def set_provider(self, provider: str) -> None:
        self.provider = provider

    def set_muted(self, muted: bool) -> None:
        self.muted = muted

    def listen(
        self,
        timeout: float = 6.0,
        phrase_time_limit: float = 12.0,
        on_level: Callable[[float], None] | None = None,
    ) -> str | None:
        if self.muted:
            return None

        if self.provider == "vosk_offline":
            return self.engines["vosk_offline"].listen_once(
                timeout=timeout, phrase_time_limit=phrase_time_limit, on_level=on_level
            )

        if self.provider == "google_web":
            return self.engines["google_web"].listen_once(
                timeout=timeout, phrase_time_limit=phrase_time_limit, on_level=on_level
            )

        # Hybrid: prefer Google uz-UZ when online, fall back cleanly to offline Vosk
        google_engine = self.engines.get("google_web")
        if google_engine is not None:
            result = google_engine.listen_once(
                timeout=timeout, phrase_time_limit=phrase_time_limit, on_level=on_level
            )
            if result:
                return result

        vosk_engine = self.engines.get("vosk_offline")
        if isinstance(vosk_engine, VoskOfflineSTTEngine) and vosk_engine.is_available:
            return vosk_engine.listen_once(
                timeout=timeout, phrase_time_limit=phrase_time_limit, on_level=on_level
            )
        return None
