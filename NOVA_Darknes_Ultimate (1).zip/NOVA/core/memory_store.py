"""Persistent memory & conversation history store for N.O.V.A. — DARKNES EDITION."""

from __future__ import annotations

import json
import uuid
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Literal

from config.settings import CONFIG_DIR

MEMORY_PATH = CONFIG_DIR / "memory.json"

MemoryCategory = Literal["preference", "project", "personal", "note"]


@dataclass
class MemoryItem:
    id: str
    category: str
    content: str
    created_at: str
    updated_at: str


@dataclass
class ConversationTurn:
    role: str  # "user" | "model"
    text: str
    timestamp: str


class MemoryStore:
    """Manages owner-approved persistent memories and cross-session conversation history."""

    def __init__(self, path: Path = MEMORY_PATH, owner_name: str = "Darknes") -> None:
        self.path = path
        self.owner_name = owner_name
        self.memories: list[MemoryItem] = []
        self.conversation_history: list[ConversationTurn] = []
        self.load()

    def load(self) -> None:
        if not self.path.exists():
            return
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            self.memories = [
                MemoryItem(
                    id=str(m.get("id") or uuid.uuid4().hex[:8]),
                    category=str(m.get("category") or "note"),
                    content=str(m.get("content") or "").strip(),
                    created_at=str(m.get("created_at") or ""),
                    updated_at=str(m.get("updated_at") or ""),
                )
                for m in raw.get("memories", [])
                if isinstance(m, dict) and str(m.get("content") or "").strip()
            ]
            self.conversation_history = [
                ConversationTurn(
                    role="user" if t.get("role") == "user" else "model",
                    text=str(t.get("text") or ""),
                    timestamp=str(t.get("timestamp") or ""),
                )
                for t in raw.get("conversation_history", [])
                if isinstance(t, dict) and str(t.get("text") or "").strip()
            ]
        except Exception:
            self.memories = []
            self.conversation_history = []

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "owner_name": self.owner_name,
            "memories": [asdict(m) for m in self.memories],
            "conversation_history": [asdict(t) for t in self.conversation_history[-80:]],
        }
        self.path.write_text(
            json.dumps(payload, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )

    def list_memories(self) -> list[MemoryItem]:
        return list(self.memories)

    def add_memory(self, content: str, category: str = "note") -> MemoryItem | None:
        cleaned = content.strip()
        if not cleaned:
            return None
        for existing in self.memories:
            if existing.content.lower() == cleaned.lower():
                return existing
        now = datetime.now().strftime("%Y-%m-%d %H:%M")
        item = MemoryItem(
            id=uuid.uuid4().hex[:8],
            category=category if category in ("preference", "project", "personal", "note") else "note",
            content=cleaned,
            created_at=now,
            updated_at=now,
        )
        self.memories.append(item)
        self.save()
        return item

    def update_memory(self, memory_id: str, new_content: str, category: str | None = None) -> bool:
        cleaned = new_content.strip()
        if not cleaned:
            return False
        for item in self.memories:
            if item.id == memory_id:
                item.content = cleaned
                if category and category in ("preference", "project", "personal", "note"):
                    item.category = category
                item.updated_at = datetime.now().strftime("%Y-%m-%d %H:%M")
                self.save()
                return True
        return False

    def delete_memory(self, memory_id: str) -> bool:
        before = len(self.memories)
        self.memories = [m for m in self.memories if m.id != memory_id]
        if len(self.memories) < before:
            self.save()
            return True
        return False

    def append_turn(self, role: str, text: str) -> None:
        cleaned = text.strip()
        if not cleaned:
            return
        stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.conversation_history.append(
            ConversationTurn(
                role="user" if role == "user" else "model",
                text=cleaned,
                timestamp=stamp,
            )
        )
        self.conversation_history = self.conversation_history[-80:]
        self.save()

    def clear_history(self) -> None:
        self.conversation_history.clear()
        self.save()
